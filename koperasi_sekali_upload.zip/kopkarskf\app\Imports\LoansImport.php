<?php

namespace App\Imports;

use App\Models\Loan;
use App\Models\Member;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsErrors;
use Carbon\Carbon;

class LoansImport implements ToModel, WithHeadingRow, WithValidation, SkipsOnError
{
    use SkipsErrors, \App\Traits\DateParserTrait;

    public function model(array $row)
    {
        $member = Member::where('member_id', $row['id_anggota'])->first();
        
        if (!$member) {
            return null;
        }

        $amount = (float) str_replace(['.', ','], ['', '.'], $row['jumlah']);
        $rate = (float) ($row['bunga'] ?? 1.5);
        $duration = (int) $row['tenor'];
        
        // Calculate totals
        $totalInterest = $amount * ($rate / 100) * ($duration / 12);
        $totalAmount = $amount + $totalInterest;
        $monthlyInstallment = $totalAmount / $duration;

        $status = strtolower($row['status'] ?? 'pending');
        $applicationDate = $this->parseDate($row['tanggal_pengajuan']);

        return new Loan([
            'member_id' => $member->id,
            'loan_number' => $row['no_pinjaman'],
            'loan_type' => strtolower($row['jenis']),
            'amount' => $amount,
            'interest_rate' => $rate,
            'duration_months' => $duration,
            'monthly_installment' => round($monthlyInstallment, 2),
            'total_amount' => round($totalAmount, 2),
            'remaining_amount' => $status === 'active' ? round($totalAmount, 2) : ($status === 'completed' ? 0 : round($totalAmount, 2)),
            'status' => $status,
            'purpose' => $row['tujuan'] ?? $row['keperluan'] ?? null,
            'application_date' => $applicationDate,
            'approval_date' => isset($row['tanggal_persetujuan']) ? $this->parseDate($row['tanggal_persetujuan']) : ($status !== 'pending' ? $applicationDate : null),
            'disbursement_date' => isset($row['tanggal_pencairan']) ? $this->parseDate($row['tanggal_pencairan']) : null,
            'approved_by' => !in_array($status, ['pending', 'rejected']) ? 1 : null,
            'notes' => $row['catatan'] ?? $row['keterangan'] ?? null,
        ]);
    }

    public function rules(): array
    {
        return [
            'id_anggota' => 'required',
            'no_pinjaman' => 'required|unique:loans,loan_number',
            'jenis' => 'required|in:regular,emergency,education,special,Regular,Emergency,Education,Special',
            'jumlah' => 'required',
            'tenor' => 'required|integer|min:1|max:60',
            'tanggal_pengajuan' => 'required',
        ];
    }

    public function customValidationMessages()
    {
        return [
            'id_anggota.required' => 'Kolom id_anggota wajib diisi',
            'no_pinjaman.required' => 'Kolom no_pinjaman wajib diisi',
            'no_pinjaman.unique' => 'Nomor pinjaman sudah terdaftar',
            'jenis.required' => 'Kolom jenis wajib diisi',
            'jenis.in' => 'Jenis harus: regular, emergency, education, atau special',
            'jumlah.required' => 'Kolom jumlah wajib diisi',
            'tenor.required' => 'Kolom tenor wajib diisi',
            'tenor.integer' => 'Tenor harus berupa angka',
            'tanggal_pengajuan.required' => 'Kolom tanggal_pengajuan wajib diisi',
        ];
    }
}
