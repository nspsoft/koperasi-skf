<?php

namespace App\Imports;

use App\Models\Saving;
use App\Models\Member;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsErrors;
use Carbon\Carbon;

class SavingsImport implements ToModel, WithHeadingRow, WithValidation, SkipsOnError
{
    use SkipsErrors, \App\Traits\DateParserTrait;

    public function model(array $row)
    {
        // Find member by member_id
        $member = Member::where('member_id', $row['id_anggota'])->first();
        
        if (!$member) {
            return null; // Skip if member not found
        }

        $amount = (float) str_replace(['.', ','], ['', '.'], $row['jumlah']);
        $type = strtolower($row['jenis']);
        $transactionType = $this->parseTransactionType($row['transaksi'] ?? 'setoran');

        return new Saving([
            'member_id' => $member->id,
            'type' => $type,
            'transaction_type' => $transactionType,
            'amount' => $amount,
            // Use the date parser trait
            'transaction_date' => $this->parseDate($row['tanggal']) ?? now(),
            'reference_number' => $row['no_referensi'] ?? 'IMP-' . date('Ymd') . '-' . rand(1000, 9999),
            'description' => $row['keterangan'] ?? 'Import dari Excel',
        ]);
    }

    protected function parseTransactionType(string $type): string
    {
        $type = strtolower(trim($type));
        
        if (in_array($type, ['penarikan', 'tarik', 'withdrawal', 'w'])) {
            return 'withdrawal';
        }
        
        return 'deposit';
    }

    public function rules(): array
    {
        return [
            'id_anggota' => 'required',
            'jenis' => 'required|in:pokok,wajib,sukarela,Pokok,Wajib,Sukarela',
            'jumlah' => 'required',
            'tanggal' => 'required',
        ];
    }

    public function customValidationMessages()
    {
        return [
            'id_anggota.required' => 'Kolom id_anggota wajib diisi',
            'jenis.required' => 'Kolom jenis wajib diisi',
            'jenis.in' => 'Jenis harus: pokok, wajib, atau sukarela',
            'jumlah.required' => 'Kolom jumlah wajib diisi',
            'tanggal.required' => 'Kolom tanggal wajib diisi',
        ];
    }
}
