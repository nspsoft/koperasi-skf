

<?php $__env->startSection('title', __('messages.titles.low_stock')); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Produk Stok Rendah</h1>
            <p class="text-gray-600 dark:text-gray-400 mt-1">
                <span class="text-red-600 font-semibold"><?php echo e($totalLowStock); ?></span> produk memerlukan restock segera.
            </p>
        </div>
        <a href="<?php echo e(route('products.index')); ?>" class="btn-secondary">
            ← Kembali ke Produk
        </a>
    </div>

    <!-- Alert Info -->
    <?php if($totalLowStock > 0): ?>
    <div class="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-xl p-4">
        <div class="flex gap-3">
            <svg class="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
            </svg>
            <div>
                <p class="font-medium text-amber-800 dark:text-amber-300">Perhatian!</p>
                <p class="text-sm text-amber-700 dark:text-amber-400">Produk dengan stok di bawah batas minimum harus segera di-restock untuk menghindari kehabisan stok.</p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="glass-card-solid p-4">
        <form method="GET" class="flex gap-4">
            <div class="flex-1">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari produk..." class="form-input">
            </div>
            <button type="submit" class="btn-primary">Cari</button>
        </form>
    </div>

    <!-- Products Table -->
    <div class="glass-card-solid overflow-hidden">
        <div class="overflow-x-auto">
            <table class="table-modern">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Kategori</th>
                        <th class="text-center">Stok Saat Ini</th>
                        <th class="text-center">Batas Minimum</th>
                        <th class="text-center">Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="flex items-center gap-3">
                                <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="w-12 h-12 rounded-lg object-cover bg-gray-100">
                                <div>
                                    <span class="font-medium text-gray-900 dark:text-white"><?php echo e($product->name); ?></span>
                                    <div class="text-xs text-gray-500"><?php echo e($product->code); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="text-gray-600 dark:text-gray-400"><?php echo e($product->category->name ?? '-'); ?></td>
                        <td class="text-center">
                            <span class="text-2xl font-bold <?php echo e($product->stock <= 0 ? 'text-red-600' : ($product->stock <= $product->min_stock * 0.5 ? 'text-orange-600' : 'text-amber-600')); ?>">
                                <?php echo e($product->stock); ?>

                            </span>
                        </td>
                        <td class="text-center text-gray-500"><?php echo e($product->min_stock); ?></td>
                        <td class="text-center">
                            <?php if($product->stock <= 0): ?>
                            <span class="badge badge-danger">Habis</span>
                            <?php elseif($product->stock <= $product->min_stock * 0.5): ?>
                            <span class="badge badge-danger">Kritis</span>
                            <?php else: ?>
                            <span class="badge badge-warning">Rendah</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button type="button" 
                                    onclick="openRestockModal(<?php echo e($product->id); ?>, '<?php echo e(addslashes($product->name)); ?>', <?php echo e($product->stock); ?>)"
                                    class="btn-success-sm">
                                + Restock
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-12">
                            <svg class="w-16 h-16 mx-auto text-green-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <p class="text-green-600 font-medium">Semua stok dalam kondisi baik!</p>
                            <p class="text-gray-500 text-sm">Tidak ada produk dengan stok rendah saat ini.</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($products->hasPages()): ?>
        <div class="p-4 border-t border-gray-100 dark:border-gray-700">
            <?php echo e($products->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Restock Modal -->
<div id="restockModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-md mx-4 p-6">
        <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-4">Tambah Stok</h3>
        <p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
            Produk: <strong id="modalProductName"></strong>
        </p>
        <p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
            Stok saat ini: <strong id="modalCurrentStock"></strong>
        </p>
        
        <form id="restockForm" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="type" value="add">
            
            <div class="mb-4">
                <label class="form-label">Jumlah Tambahan</label>
                <input type="number" name="quantity" min="1" value="10" class="form-input" required>
            </div>
            
            <div class="flex gap-3">
                <button type="button" onclick="closeRestockModal()" class="btn-secondary flex-1">Batal</button>
                <button type="submit" class="btn-success flex-1">Tambah Stok</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    function openRestockModal(productId, productName, currentStock) {
        document.getElementById('modalProductName').textContent = productName;
        document.getElementById('modalCurrentStock').textContent = currentStock + ' unit';
        document.getElementById('restockForm').action = '/inventory/' + productId + '/update-stock';
        document.getElementById('restockModal').classList.remove('hidden');
        document.getElementById('restockModal').classList.add('flex');
    }
    
    function closeRestockModal() {
        document.getElementById('restockModal').classList.add('hidden');
        document.getElementById('restockModal').classList.remove('flex');
    }
    
    // Close on outside click
    document.getElementById('restockModal').addEventListener('click', function(e) {
        if (e.target === this) closeRestockModal();
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Koperasi\resources\views/inventory/low-stock.blade.php ENDPATH**/ ?>