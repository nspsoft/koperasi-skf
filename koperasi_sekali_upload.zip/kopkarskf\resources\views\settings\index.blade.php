@extends('layouts.app')

@section('title', __('messages.titles.settings'))

@section('content')
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Pengaturan Sistem</h1>
            <p class="page-subtitle">Konfigurasi profil koperasi dan parameter sistem</p>
        </div>
    </div>

    <!-- Quick Access Cards -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <a href="{{ route('settings.ai') }}" class="glass-card p-4 hover:shadow-lg transition-all group">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center text-purple-600 group-hover:scale-110 transition-transform">
                    🤖
                </div>
                <div>
                    <h4 class="font-semibold text-gray-900 dark:text-white text-sm">AI Assistant</h4>
                    <p class="text-xs text-gray-500">Konfigurasi AI</p>
                </div>
            </div>
        </a>
        <a href="{{ route('settings.landing') }}" class="glass-card p-4 hover:shadow-lg transition-all group">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
                    🌐
                </div>
                <div>
                    <h4 class="font-semibold text-gray-900 dark:text-white text-sm">Landing Page</h4>
                    <p class="text-xs text-gray-500">Halaman Publik</p>
                </div>
            </div>
        </a>
        <a href="{{ route('settings.backup') }}" class="glass-card p-4 hover:shadow-lg transition-all group">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center text-green-600 group-hover:scale-110 transition-transform">
                    💾
                </div>
                <div>
                    <h4 class="font-semibold text-gray-900 dark:text-white text-sm">Backup</h4>
                    <p class="text-xs text-gray-500">Cadangan Data</p>
                </div>
            </div>
        </a>
        <a href="{{ route('settings.audit-logs') }}" class="glass-card p-4 hover:shadow-lg transition-all group">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-xl flex items-center justify-center text-amber-600 group-hover:scale-110 transition-transform">
                    📋
                </div>
                <div>
                    <h4 class="font-semibold text-gray-900 dark:text-white text-sm">Audit Log</h4>
                    <p class="text-xs text-gray-500">Riwayat Aktivitas</p>
                </div>
            </div>
        </a>
    </div>

    <form action="{{ route('settings.update') }}" method="POST" enctype="multipart/form-data">
        @csrf
        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- General Profile -->
            <div class="glass-card-solid p-6">
                <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                    <svg class="w-5 h-5 text-primary-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
                    </svg>
                    Profil Koperasi
                </h3>

                <div class="space-y-4">
                    <!-- Logo Upload -->
                    <div class="form-group">
                        <label class="form-label">Logo Koperasi</label>
                        <div class="flex items-center gap-4">
                            @if(isset($settings['coop_logo']))
                                <img src="{{ Storage::url($settings['coop_logo']) }}" alt="Logo" class="w-16 h-16 object-contain bg-gray-100 rounded-lg p-1 border">
                            @endif
                            <input type="file" name="logo" accept="image/*" class="block w-full text-sm text-gray-500
                                file:mr-4 file:py-2 file:px-4
                                file:rounded-full file:border-0
                                file:text-sm file:font-semibold
                                file:bg-primary-50 file:text-primary-700
                                hover:file:bg-primary-100
                            "/>
                        </div>
                        <p class="text-xs text-gray-400 mt-1">Format: PNG/JPG, Max 2MB. Digunakan untuk Kartu Anggota & Laporan.</p>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Nama Koperasi</label>
                        <input type="text" name="coop_name" value="{{ $settings['coop_name'] ?? 'SPINDO KARAWANG FACTORY' }}" class="form-input">
                    </div>
                     <div class="form-group">
                        <label class="form-label">Alamat Lengkap</label>
                        <textarea name="coop_address" rows="3" class="form-input">{{ $settings['coop_address'] ?? '' }}</textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Nomor Telepon / WA</label>
                        <input type="text" name="coop_phone" value="{{ $settings['coop_phone'] ?? '' }}" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email Resmi</label>
                        <input type="email" name="coop_email" value="{{ $settings['coop_email'] ?? '' }}" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">URL Akses Mobile (untuk QR Code)</label>
                        <input type="text" name="app_url" value="{{ $settings['app_url'] ?? 'http://192.168.110.39/Koperasi/public' }}" class="form-input" placeholder="http://192.168.1.100/Koperasi/public">
                        <p class="text-xs text-gray-400 mt-1">URL ini akan ditampilkan sebagai QR Code di Dashboard untuk akses dari HP</p>
                    </div>

                    <!-- Document Logos -->
                    <div class="pt-4 mt-4 border-t border-gray-100 dark:border-gray-700">
                        <h4 class="text-sm font-semibold text-gray-900 dark:text-white mb-4">Logo Kop Surat & Dokumen</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="form-group">
                                <label class="form-label text-xs">Logo 1 (Koperasi Indonesia)</label>
                                <div class="flex items-center gap-3">
                                    @if(isset($settings['doc_logo_1']))
                                        <img src="{{ Storage::url($settings['doc_logo_1']) }}" class="w-10 h-10 object-contain bg-gray-50 rounded border">
                                    @endif
                                    <input type="file" name="doc_logo_1" accept="image/*" class="text-xs text-gray-500 file:mr-2 file:py-1 file:px-3 file:rounded-full file:border-0 file:text-xs file:bg-primary-50">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label text-xs">Logo 2 (Kopkar SKF)</label>
                                <div class="flex items-center gap-3">
                                    @if(isset($settings['doc_logo_2']))
                                        <img src="{{ Storage::url($settings['doc_logo_2']) }}" class="w-10 h-10 object-contain bg-gray-50 rounded border">
                                    @endif
                                    <input type="file" name="doc_logo_2" accept="image/*" class="text-xs text-gray-500 file:mr-2 file:py-1 file:px-3 file:rounded-full file:border-0 file:text-xs file:bg-primary-50">
                                </div>
                            </div>
                        </div>
                        <p class="text-[10px] text-gray-400 mt-2">Logo ini akan muncul di bagian kiri dan kanan header (Kop Surat) pada setiap dokumen yang di-generate.</p>
                    </div>
                </div>
            </div>

            <!-- WhatsApp Configuration -->
            <div class="glass-card-solid p-6">
                <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                    <svg class="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
                    </svg>
                    WhatsApp Floating Button
                </h3>

                <div class="space-y-4">
                    <div class="form-group">
                        <label class="form-label">Nomor WhatsApp Admin</label>
                        <input type="text" name="whatsapp_number" value="{{ $settings['whatsapp_number'] ?? '' }}" class="form-input" placeholder="6281234567890">
                        <p class="text-xs text-gray-400 mt-1">Gunakan format internasional tanpa + (contoh: 6281234567890). Kosongkan untuk menyembunyikan tombol.</p>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Pesan Default</label>
                        <textarea name="whatsapp_message" rows="2" class="form-input" placeholder="Halo Admin...">{{ $settings['whatsapp_message'] ?? 'Halo, saya butuh bantuan.' }}</textarea>
                        <p class="text-xs text-gray-400 mt-1">Pesan otomatis yang akan muncul saat chat dibuka.</p>
                    </div>
                </div>
            </div>

            <!-- Savings Configuration -->
            <div class="glass-card-solid p-6">
                <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                    <svg class="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    Parameter Simpanan (Default)
                </h3>

                <div class="space-y-4">
                    <div class="form-group">
                        <label class="form-label">Simpanan Pokok (Rp)</label>
                        <input type="number" name="saving_principal" value="{{ $settings['saving_principal'] ?? '' }}" class="form-input" placeholder="Contoh: 100000">
                        <p class="text-xs text-gray-400 mt-1">Nilai default untuk input Simpanan Pokok</p>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Simpanan Wajib (Rp)</label>
                        <input type="number" name="saving_mandatory" value="{{ $settings['saving_mandatory'] ?? '' }}" class="form-input" placeholder="Contoh: 50000">
                        <p class="text-xs text-gray-400 mt-1">Nilai default untuk input Simpanan Wajib</p>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Default Limit Kredit Mart (Rp)</label>
                        <input type="number" name="default_credit_limit" value="{{ $settings['default_credit_limit'] ?? '500000' }}" class="form-input" placeholder="Contoh: 500000">
                        <p class="text-xs text-gray-400 mt-1">Limit kredit belanja di Koperasi Mart untuk member baru</p>
                    </div>
                </div>
            </div>

            <!-- Loan Configuration -->
            <div class="glass-card-solid p-6">
                <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                    <svg class="w-5 h-5 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    Parameter Pinjaman (Default)
                </h3>

                <div class="space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div class="form-group">
                            <label class="form-label">Bunga Reguler (%)</label>
                            <input type="number" step="0.01" name="loan_interest_regular" value="{{ $settings['loan_interest_regular'] ?? '1.5' }}" class="form-input">
                            <p class="text-xs text-gray-400 mt-1">Per bulan</p>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Max Tenor (Bulan)</label>
                            <input type="number" name="loan_max_duration" value="{{ $settings['loan_max_duration'] ?? '60' }}" class="form-input">
                        </div>
                    </div>
                     <div class="form-group">
                        <label class="form-label">Batas Pinjaman Maksimal (Rp)</label>
                        <input type="number" name="loan_limit_max" value="{{ $settings['loan_limit_max'] ?? '50000000' }}" class="form-input">
                    </div>
                    
                    <div class="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-700">
                        <p class="text-sm text-yellow-800 dark:text-yellow-300">
                            <strong>Catatan:</strong> Pengubahan nilai default ini tidak akan mengubah kontrak pinjaman yang sudah berjalan (Aktif), hanya berlaku untuk pengajuan baru.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Payment Configuration (QRIS) -->
            <div class="glass-card-solid p-6">
                <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                    <svg class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path>
                    </svg>
                    Rekening Pembayaran & QRIS
                </h3>

                <div class="space-y-4">
                    <div class="form-group">
                        <label class="form-label">Nama Bank</label>
                        <input type="text" name="bank_name" value="{{ $settings['bank_name'] ?? '' }}" class="form-input" placeholder="Contoh: Bank Mandiri">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Nomor Rekening</label>
                        <input type="text" name="bank_account" value="{{ $settings['bank_account'] ?? '' }}" class="form-input" placeholder="Contoh: 1234567890">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Atas Nama</label>
                        <input type="text" name="bank_holder" value="{{ $settings['bank_holder'] ?? '' }}" class="form-input" placeholder="Contoh: Koperasi Karyawan">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Gambar QRIS</label>
                        <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl border border-dashed border-gray-300 dark:border-gray-600 text-center">
                            @if(isset($settings['payment_qris_image']) && $settings['payment_qris_image'])
                                <img src="{{ Storage::url($settings['payment_qris_image']) }}" alt="QRIS" class="mx-auto h-48 object-contain rounded-lg mb-4 shadow-md">
                            @else
                                <div class="mx-auto h-32 bg-gray-200 dark:bg-gray-700 rounded-lg mb-4 flex items-center justify-center text-gray-400">
                                    <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"></path></svg>
                                </div>
                            @endif
                            
                            <input type="file" name="qris_image" accept="image/*" class="block w-full text-sm text-gray-500
                                file:mr-4 file:py-2 file:px-4
                                file:rounded-full file:border-0
                                file:text-sm file:font-semibold
                                file:bg-blue-50 file:text-blue-700
                                hover:file:bg-blue-100
                            "/>
                            <p class="text-xs text-gray-400 mt-2">Upload gambar QRIS untuk pembayaran digital</p>
                        </div>
                    </div>

                    <div class="mt-4 pt-4 border-t border-blue-200 dark:border-blue-800">
                        <p class="text-[10px] text-blue-600 dark:text-blue-500 font-medium italic">
                            *QRIS bersifat legal dan diawasi Bank Indonesia. Satu QRIS bisa menerima pembayaran dari semua jenis e-wallet/mobile banking.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="lg:col-span-2 flex justify-end pt-6 border-t border-gray-100 dark:border-gray-700">
                 <button type="submit" class="btn-primary">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"></path>
                    </svg>
                    Simpan Perubahan
                </button>
            </div>
        </div>
    </form>
@endsection
