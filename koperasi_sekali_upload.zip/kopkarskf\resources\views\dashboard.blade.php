@extends('layouts.app')

@section('title', __('messages.titles.dashboard'))

@section('content')
    <div class="page-header">
        <h1 class="page-title">Dashboard</h1>
        <p class="page-subtitle">Selamat datang kembali, {{ auth()->user()->name }}!</p>
    </div>

    <div class="glass-card-solid p-6 border-l-4 border-l-indigo-500">
        <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Status Keanggotaan</h3>
        <div class="mt-4">
            @if(auth()->user()->member)
                @if(auth()->user()->member->status === 'active')
                    <span class="badge badge-success text-base px-4 py-2">Anggota Aktif</span>
                    <p class="mt-2 text-gray-600">ID Anggota: {{ auth()->user()->member->member_id }}</p>
                @elseif(auth()->user()->member->status === 'inactive')
                    <span class="badge badge-warning text-base px-4 py-2">Menunggu Persetujuan</span>
                    <p class="mt-2 text-gray-600">Data pendaftaran Anda sedang direview oleh admin.</p>
                @else
                    <span class="badge badge-danger text-base px-4 py-2">Tidak Aktif / Resign</span>
                @endif
            @else
                <span class="badge badge-secondary text-base px-4 py-2">Bukan Anggota</span>
                <p class="mt-2 text-gray-600">Anda belum terdaftar sebagai anggota Koperasi.</p>
            @endif
        </div>
    </div>
@endsection
