<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'category_id', 'code', 'name', 'description', 
        'price', 'cost', 'stock', 'min_stock', 'image', 'is_active',
        'is_preorder', 'preorder_eta'
    ];

    protected $casts = [
        'is_preorder' => 'boolean',
        'is_active' => 'boolean',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * Check if product stock is below minimum threshold
     */
    public function isLowStock()
    {
        return $this->stock <= $this->min_stock;
    }

    /**
     * Scope to get low stock products
     */
    public function scopeLowStock($query)
    {
        return $query->whereColumn('stock', '<=', 'min_stock')
                     ->where('is_active', true);
    }

    /**
     * Get low stock level (critical, warning, ok)
     */
    public function getStockLevelAttribute()
    {
        if ($this->stock <= 0) return 'out';
        if ($this->stock <= $this->min_stock * 0.5) return 'critical';
        if ($this->stock <= $this->min_stock) return 'warning';
        return 'ok';
    }

    public function reviews()
    {
        return $this->hasMany(Review::class)->where('is_visible', true);
    }

    public function getAverageRatingAttribute()
    {
        return round($this->reviews()->avg('rating') ?: 0, 1);
    }

    /**
     * Get product image URL - uploaded or auto-generated placeholder
     */
    public function getImageUrlAttribute()
    {
        // If product has uploaded image, use it
        if ($this->image) {
            return \Storage::url($this->image);
        }

        // Fallback: Use placehold.co for placeholder with product name and category color
        $colors = [
            'sembako' => '4f46e5/ffffff',     // indigo
            'makanan ringan' => 'f97316/ffffff', // orange
            'minuman' => '06b6d4/ffffff',      // cyan
            'atk' => '8b5cf6/ffffff',          // violet 
            'kebersihan' => '22c55e/ffffff',   // green
        ];

        $bgColor = '6366f1/ffffff'; // default: indigo
        if ($this->category) {
            $categoryName = strtolower($this->category->name);
            foreach ($colors as $key => $color) {
                if (str_contains($categoryName, $key)) {
                    $bgColor = $color;
                    break;
                }
            }
        }

        $text = urlencode($this->name);
        return "https://placehold.co/400x400/{$bgColor}?text={$text}&font=roboto";
    }

    /**
     * Get appropriate keyword for image search based on product name
     */
    protected function getImageKeyword()
    {
        $name = strtolower($this->name);
        
        // Mapping nama produk Indonesia ke keyword English untuk Unsplash
        $keywords = [
            // Sembako
            'beras' => 'rice,grain',
            'minyak' => 'cooking,oil',
            'gula' => 'sugar',
            'tepung' => 'flour',
            'telur' => 'eggs',
            'kecap' => 'soy,sauce',
            'garam' => 'salt',
            'mie' => 'noodles,instant',
            'indomie' => 'noodles,instant',
            
            // Minuman
            'kopi' => 'coffee',
            'teh' => 'tea',
            'susu' => 'milk',
            'air mineral' => 'water,bottle',
            'sirup' => 'syrup',
            'jus' => 'juice',
            
            // Makanan Ringan
            'biskuit' => 'biscuit,cookies',
            'coklat' => 'chocolate',
            'keripik' => 'chips,snack',
            'wafer' => 'wafer',
            'permen' => 'candy',
            'roti' => 'bread',
            'silverqueen' => 'chocolate,bar',
            
            // Kebersihan
            'sabun' => 'soap',
            'shampo' => 'shampoo',
            'pasta gigi' => 'toothpaste',
            'sikat gigi' => 'toothbrush',
            'deterjen' => 'detergent',
            'pewangi' => 'fabric,softener',
            'rinso' => 'detergent,powder',
            'sunlight' => 'dish,soap',
            'lifebuoy' => 'soap,bar',
            'pepsodent' => 'toothpaste',
            
            // ATK
            'buku' => 'notebook,book',
            'pulpen' => 'pen,ballpoint',
            'pensil' => 'pencil',
            'penghapus' => 'eraser',
            'kertas' => 'paper,a4',
            'staples' => 'stapler',
            'lem' => 'glue',
            'gunting' => 'scissors',
        ];

        // Find matching keyword
        foreach ($keywords as $key => $value) {
            if (str_contains($name, $key)) {
                return urlencode($value);
            }
        }

        // Default: use category name or generic product
        if ($this->category) {
            $categoryKeywords = [
                'sembako' => 'grocery,food',
                'makanan ringan' => 'snack,food',
                'minuman' => 'beverage,drink',
                'atk' => 'office,supplies',
                'kebersihan' => 'cleaning,products',
            ];

            $categoryName = strtolower($this->category->name);
            foreach ($categoryKeywords as $key => $value) {
                if (str_contains($categoryName, $key)) {
                    return urlencode($value);
                }
            }
        }

        return 'product,grocery';
    }
}
