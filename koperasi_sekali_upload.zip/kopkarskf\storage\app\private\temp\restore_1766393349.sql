-- MySQL dump 10.13  Distrib 8.4.3, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: koperasi
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('info','warning','important','event') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info',
  `priority` enum('low','medium','high') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `publish_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcements_created_by_foreign` (`created_by`),
  CONSTRAINT `announcements_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (1,'Selamat Datang di Koperasi Karyawan PT. SPINDO','Website Koperasi Karyawan PT. SPINDO Karawang Factory telah diluncurkan. Silakan login menggunakan akun Anda untuk mengakses fitur simpanan dan pinjaman.','important','high',1,'2025-12-21',NULL,NULL,1,'2025-12-20 21:01:05','2025-12-20 21:01:05'),(2,'Info Simpanan Wajib Bulanan','Simpanan wajib bulanan sebesar Rp 50.000 akan dipotong otomatis dari gaji setiap bulannya. Pastikan saldo Anda mencukupi.','info','medium',1,'2025-12-21',NULL,NULL,1,'2025-12-20 21:01:05','2025-12-20 21:01:05');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Makanan Ringan','makanan-ringan','🍿','Aneka snack dan camilan','2025-12-21 00:09:21','2025-12-21 00:09:21'),(2,'Minuman','minuman','🥤','Minuman segar dan kemasan','2025-12-21 00:09:21','2025-12-21 00:09:21'),(3,'Sembako','sembako','🍚','Beras, Minyak, Gula, dll','2025-12-21 00:09:21','2025-12-21 00:09:21'),(4,'ATK','atk','✏️','Alat Tulis Kantor','2025-12-21 00:09:22','2025-12-21 00:09:22'),(5,'Kebersihan','kebersihan','🧹','Sabun, Deterjen, dll','2025-12-21 00:09:22','2025-12-21 00:09:22');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `departments_name_unique` (`name`),
  UNIQUE KEY `departments_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'Production','PROD','Departemen Produksi',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(2,'Quality Control','QC','Departemen Quality Control',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(3,'Warehouse','WH','Departemen Gudang',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(4,'Maintenance','MTC','Departemen Maintenance',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(5,'Human Resources','HR','Departemen SDM',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(6,'Finance','FIN','Departemen Keuangan',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(7,'IT','IT','Departemen IT',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(8,'Purchasing','PUR','Departemen Pembelian',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(9,'Marketing','MKT','Departemen Marketing',1,'2025-12-20 21:35:45','2025-12-20 21:35:45');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments_and_positions_tables`
--

DROP TABLE IF EXISTS `departments_and_positions_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments_and_positions_tables` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments_and_positions_tables`
--

LOCK TABLES `departments_and_positions_tables` WRITE;
/*!40000 ALTER TABLE `departments_and_positions_tables` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments_and_positions_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_payments`
--

DROP TABLE IF EXISTS `loan_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `loan_id` bigint unsigned NOT NULL,
  `payment_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installment_number` int NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `principal_amount` decimal(15,2) NOT NULL,
  `interest_amount` decimal(15,2) NOT NULL,
  `due_date` date NOT NULL,
  `payment_date` date DEFAULT NULL,
  `status` enum('pending','paid','overdue','partial') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_method` enum('cash','transfer','salary_deduction') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `received_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_payments_loan_id_foreign` (`loan_id`),
  KEY `loan_payments_received_by_foreign` (`received_by`),
  CONSTRAINT `loan_payments_loan_id_foreign` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loan_payments_received_by_foreign` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_payments`
--

LOCK TABLES `loan_payments` WRITE;
/*!40000 ALTER TABLE `loan_payments` DISABLE KEYS */;
INSERT INTO `loan_payments` VALUES (1,2,'PAY202512210001',1,265000.00,265000.00,0.00,'2025-12-21','2025-12-21','paid','salary_deduction',NULL,1,'2025-12-20 21:48:29','2025-12-20 21:48:29'),(2,2,'PAY202512210002',2,265000.00,265000.00,0.00,'2025-12-22','2025-12-22','paid','transfer',NULL,1,'2025-12-20 21:48:52','2025-12-20 21:48:52');
/*!40000 ALTER TABLE `loan_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loans`
--

DROP TABLE IF EXISTS `loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `member_id` bigint unsigned NOT NULL,
  `loan_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_type` enum('regular','emergency','education','special') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'regular',
  `amount` decimal(15,2) NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL DEFAULT '1.00',
  `duration_months` int NOT NULL,
  `monthly_installment` decimal(15,2) NOT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `remaining_amount` decimal(15,2) NOT NULL,
  `status` enum('pending','approved','rejected','active','completed','defaulted') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `signature` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signed_at` timestamp NULL DEFAULT NULL,
  `application_date` date NOT NULL,
  `approval_date` date DEFAULT NULL,
  `disbursement_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `purpose` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `approved_by` bigint unsigned DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `loans_loan_number_unique` (`loan_number`),
  KEY `loans_member_id_foreign` (`member_id`),
  KEY `loans_approved_by_foreign` (`approved_by`),
  KEY `loans_created_by_foreign` (`created_by`),
  CONSTRAINT `loans_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `loans_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `loans_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loans`
--

LOCK TABLES `loans` WRITE;
/*!40000 ALTER TABLE `loans` DISABLE KEYS */;
INSERT INTO `loans` VALUES (1,1,'PNJ202512210001','education',1000000.00,1.00,3,343333.33,1030000.00,1030000.00,'active','signatures/PNJ202512210001_1766298077.png','2025-12-20 23:21:17','2025-12-21','2025-12-21','2025-12-21','2026-01-21','Sekolah Anak',NULL,1,1,'2025-12-20 21:45:55','2025-12-21 04:08:04'),(2,4,'PNJ202512210002','emergency',1500000.00,1.00,6,265000.00,1590000.00,1060000.00,'active','signatures/PNJ202512210002_1766292415.png','2025-12-20 21:46:55','2025-12-21','2025-12-21','2025-12-21','2026-01-21','Buat Berobat Anak',NULL,1,1,'2025-12-20 21:46:25','2025-12-20 21:48:52'),(3,5,'PNJ202512220001','special',600000.00,1.00,3,206000.00,618000.00,618000.00,'approved','signatures/PNJ202512220001_1766374554.png','2025-12-21 20:35:54','2025-12-22','2025-12-22',NULL,NULL,'Kepentingan Keluarga',NULL,1,1,'2025-12-21 20:32:58','2025-12-21 20:35:54'),(4,4,'PNJ202512220002','education',500000.00,1.00,1,505000.00,505000.00,505000.00,'approved',NULL,NULL,'2025-12-22','2025-12-22',NULL,NULL,'Sekolah Anak',NULL,1,1,'2025-12-21 20:33:55','2025-12-21 20:36:07'),(5,1,'PNJ202512220003','regular',1000000.00,1.00,6,176666.67,1060000.00,1060000.00,'pending',NULL,NULL,'2025-12-22',NULL,NULL,NULL,'Kebutuhan',NULL,NULL,1,'2025-12-21 20:35:01','2025-12-21 20:35:01');
/*!40000 ALTER TABLE `loans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `member_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `join_date` date NOT NULL,
  `status` enum('active','inactive','resigned') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `points` int NOT NULL DEFAULT '0',
  `credit_limit` decimal(15,2) NOT NULL DEFAULT '500000.00',
  `address` text COLLATE utf8mb4_unicode_ci,
  `id_card_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('male','female') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `members_member_id_unique` (`member_id`),
  KEY `members_user_id_foreign` (`user_id`),
  CONSTRAINT `members_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (1,3,'KOP20250001','KA073','PPIC','Kasie PPIC','2025-12-21','active',4,500000.00,'Karawang, Jawa Barat','3215010101990001','1990-01-01','male','members/G7mDA1NymVbuEoJf5lgpkVRPn7tw5dDDUn6gegBM.png','2025-12-20 21:01:05','2025-12-21 08:11:14'),(2,1,'KOP20250000','ADM001','Management','Administrator','2024-12-21','active',0,500000.00,'Karawang, Jawa Barat','3215010101980001','1980-01-01','male',NULL,'2025-12-20 21:01:05','2025-12-20 21:01:05'),(4,5,'KOP20250002','KA015','Warehouse','Karu RM','2025-12-21','active',0,500000.00,'Karawang, Jawa Barat','3714031012890005','1985-12-25','male',NULL,'2025-12-20 21:39:24','2025-12-20 21:39:24'),(5,6,'KOP20250003','KA015','Production','Operator','2025-12-21','active',0,500000.00,'Karawang, Jawa Barat','37140310108500001','1989-12-10','male',NULL,'2025-12-20 23:05:44','2025-12-20 23:30:38');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_12_20_095049_create_members_table',1),(5,'2025_12_20_095051_create_savings_table',1),(6,'2025_12_20_095053_create_loans_table',1),(7,'2025_12_20_095054_create_loan_payments_table',1),(8,'2025_12_20_095056_create_settings_table',1),(9,'2025_12_20_095058_create_announcements_table',1),(10,'2025_12_20_150649_add_signature_to_loans_table',1),(11,'2025_12_21_042200_create_departments_and_positions_tables',2),(12,'2025_12_21_043436_create_departments_and_positions_tables',2),(13,'2025_12_21_065827_create_categories_table',3),(14,'2025_12_21_065830_create_products_table',3),(15,'2025_12_21_065833_create_transactions_table',3),(16,'2025_12_21_065836_create_transaction_items_table',3),(17,'2025_12_21_090824_add_credit_status_to_transactions_table',4),(18,'2025_12_21_091214_add_credit_limit_to_members_table',5),(19,'2025_12_21_125442_create_vouchers_table',6),(20,'2025_12_21_125925_create_reviews_table',7),(21,'2025_12_21_150956_add_points_to_members_table',8),(22,'2025_12_21_151326_add_preorder_fields_to_products_table',9),(23,'2025_12_22_054549_create_team_members_table',10),(24,'2025_12_22_074142_create_work_programs_table',11),(25,'2025_12_22_082949_create_performance_histories_table',12);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `performance_histories`
--

DROP TABLE IF EXISTS `performance_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `points_change` int NOT NULL,
  `type` enum('add','deduct') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'add',
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `performance_histories_user_id_foreign` (`user_id`),
  KEY `performance_histories_admin_id_foreign` (`admin_id`),
  CONSTRAINT `performance_histories_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `performance_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performance_histories`
--

LOCK TABLES `performance_histories` WRITE;
/*!40000 ALTER TABLE `performance_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `performance_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `positions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `positions_name_unique` (`name`),
  UNIQUE KEY `positions_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `positions`
--

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,'Staff','STF','Karyawan Staff',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(2,'Supervisor','SPV','Supervisor',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(3,'Manager','MGR','Manager',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(4,'Assistant Manager','ASSMGR','Assistant Manager',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(5,'Team Leader','TL','Team Leader',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(6,'Senior Staff','SRSTF','Senior Staff',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(7,'Junior Staff','JRSTF','Junior Staff',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(8,'Operator','OPR','Operator',1,'2025-12-20 21:35:45','2025-12-20 21:35:45'),(9,'Technician','TECH','Technician',1,'2025-12-20 21:35:45','2025-12-20 21:35:45');
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(15,2) NOT NULL,
  `cost` decimal(15,2) NOT NULL DEFAULT '0.00',
  `stock` int NOT NULL DEFAULT '0',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_preorder` tinyint(1) NOT NULL DEFAULT '0',
  `preorder_eta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_code_unique` (`code`),
  KEY `products_category_id_foreign` (`category_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,'MR001','Chitato Sapi Panggang 68g','Deskripsi untuk Chitato Sapi Panggang 68g',11500.00,10000.00,38,'products/oY5u8VsaeYZ7LC1j4FP2SuQpQXy344AZGTeLDvpb.png',0,NULL,1,'2025-12-21 00:09:21','2025-12-21 04:37:32'),(2,1,'MR002','Oreo Original 133g','Deskripsi untuk Oreo Original 133g',9500.00,8000.00,44,'products/qR5g0kIcHa5vZLZ7iMEzqt7nLGaxALxZE8MiGCCQ.png',0,NULL,1,'2025-12-21 00:09:21','2025-12-21 04:37:32'),(3,1,'MR003','Qtela Singkong Balado','Deskripsi untuk Qtela Singkong Balado',15000.00,13500.00,29,'products/2kQxibuuDteQf7LVxnHWRG7TW6PHzv7VOwSlipzb.png',0,NULL,1,'2025-12-21 00:09:21','2025-12-21 04:37:32'),(4,1,'MR004','Beng Beng Wafer','Deskripsi untuk Beng Beng Wafer',2500.00,2000.00,89,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 04:37:32'),(5,1,'MR005','Silverqueen Chunky Bar','Deskripsi untuk Silverqueen Chunky Bar',22000.00,18000.00,15,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 04:32:11'),(6,2,'MN001','Teh Botol Sosro 450ml','Deskripsi untuk Teh Botol Sosro 450ml',6000.00,4500.00,59,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 04:32:11'),(7,2,'MN002','Aqua Botol 600ml','Deskripsi untuk Aqua Botol 600ml',4000.00,3000.00,89,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 04:32:11'),(8,2,'MN003','Coca Cola 390ml','Deskripsi untuk Coca Cola 390ml',5500.00,4200.00,34,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 02:18:40'),(9,2,'MN004','Pocari Sweat 500ml','Deskripsi untuk Pocari Sweat 500ml',8000.00,6500.00,27,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 01:06:56'),(10,2,'MN005','Kopi Kapal Api Botol','Deskripsi untuk Kopi Kapal Api Botol',5000.00,3800.00,44,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 01:06:56'),(11,2,'MN006','Susu Bear Brand','Deskripsi untuk Susu Bear Brand',12000.00,10500.00,84,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 01:06:56'),(12,3,'SB001','Beras Pandan Wangi 5kg','Deskripsi untuk Beras Pandan Wangi 5kg',85000.00,78000.00,16,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 01:06:56'),(13,3,'SB002','Minyak Goreng Sania 2L','Deskripsi untuk Minyak Goreng Sania 2L',38000.00,35000.00,29,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 00:49:42'),(14,3,'SB003','Gula Pasir Gulaku 1kg','Deskripsi untuk Gula Pasir Gulaku 1kg',16500.00,15000.00,44,NULL,0,NULL,1,'2025-12-21 00:09:21','2025-12-21 00:49:42'),(15,3,'SB004','Telur Ayam 1kg','Deskripsi untuk Telur Ayam 1kg',28000.00,25000.00,9,NULL,0,NULL,1,'2025-12-21 00:09:22','2025-12-21 00:49:42'),(16,3,'SB005','Kecap Bango Manis 550ml','Deskripsi untuk Kecap Bango Manis 550ml',24000.00,21000.00,24,NULL,0,NULL,1,'2025-12-21 00:09:22','2025-12-21 00:49:42'),(17,3,'SB006','Indomie Goreng (Kardus)','Deskripsi untuk Indomie Goreng (Kardus)',110000.00,105000.00,13,NULL,0,NULL,1,'2025-12-21 00:09:22','2025-12-21 00:52:36'),(18,4,'AT001','Buku Tulis Sidu 38 Lembar','Deskripsi untuk Buku Tulis Sidu 38 Lembar',4500.00,3000.00,0,NULL,1,'7',1,'2025-12-21 00:09:22','2025-12-21 08:24:31'),(19,4,'AT002','Pulpen Standard AE7','Deskripsi untuk Pulpen Standard AE7',2500.00,1500.00,198,NULL,0,NULL,1,'2025-12-21 00:09:22','2025-12-21 00:52:36'),(20,4,'AT003','Kertas A4 Sidu 70gsm (Rim)','Deskripsi untuk Kertas A4 Sidu 70gsm (Rim)',45000.00,40000.00,29,NULL,0,NULL,1,'2025-12-21 00:09:22','2025-12-21 00:15:51'),(21,4,'AT004','Isi Staples No. 10','Deskripsi untuk Isi Staples No. 10',2000.00,1000.00,48,NULL,0,NULL,1,'2025-12-21 00:09:22','2025-12-21 00:52:36'),(22,5,'KB001','Rinso Anti Noda 700g','Deskripsi untuk Rinso Anti Noda 700g',22000.00,19000.00,28,NULL,0,NULL,1,'2025-12-21 00:09:22','2025-12-21 00:42:02'),(23,5,'KB002','Sunlight Jeruk Nipis 780ml','Deskripsi untuk Sunlight Jeruk Nipis 780ml',15000.00,12500.00,36,NULL,0,NULL,1,'2025-12-21 00:09:22','2025-12-21 01:33:58'),(24,5,'KB003','Lifebuoy Body Wash 450ml','Deskripsi untuk Lifebuoy Body Wash 450ml',25000.00,21000.00,23,NULL,0,NULL,1,'2025-12-21 00:09:22','2025-12-21 00:42:02'),(25,5,'KB004','Pasta Gigi Pepsodent 120g','Deskripsi untuk Pasta Gigi Pepsodent 120g',11000.00,9000.00,55,NULL,0,NULL,1,'2025-12-21 00:09:22','2025-12-21 08:11:14');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `rating` int NOT NULL DEFAULT '5',
  `comment` text COLLATE utf8mb4_unicode_ci,
  `is_visible` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_product_id_foreign` (`product_id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES (1,1,3,3,'kurang puas',1,'2025-12-21 06:20:13','2025-12-21 06:55:14');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `savings`
--

DROP TABLE IF EXISTS `savings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `savings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `member_id` bigint unsigned NOT NULL,
  `type` enum('pokok','wajib','sukarela') COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_type` enum('deposit','withdrawal') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'deposit',
  `amount` decimal(15,2) NOT NULL,
  `transaction_date` date NOT NULL,
  `reference_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `savings_member_id_foreign` (`member_id`),
  KEY `savings_created_by_foreign` (`created_by`),
  CONSTRAINT `savings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `savings_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `savings`
--

LOCK TABLES `savings` WRITE;
/*!40000 ALTER TABLE `savings` DISABLE KEYS */;
INSERT INTO `savings` VALUES (5,1,'pokok','deposit',150000.00,'2025-12-21','SMP202512210001',NULL,1,'2025-12-20 21:49:45','2025-12-20 21:49:45'),(6,1,'wajib','deposit',100000.00,'2025-12-21','SMP202512210002',NULL,1,'2025-12-20 21:49:59','2025-12-20 21:49:59'),(7,4,'pokok','deposit',150000.00,'2025-12-21','SMP202512210003',NULL,1,'2025-12-20 21:50:18','2025-12-20 21:50:18'),(8,4,'wajib','deposit',100000.00,'2025-12-21','SMP202512210004',NULL,1,'2025-12-20 21:50:30','2025-12-20 21:50:30'),(9,1,'sukarela','deposit',1200000.00,'2025-12-21','SMP202512210005',NULL,1,'2025-12-21 03:45:38','2025-12-21 03:45:38'),(10,1,'sukarela','withdrawal',-60500.00,'2025-12-21',NULL,'Pembayaran Belanja: TRX-20251221-GIVX',1,'2025-12-21 04:25:14','2025-12-21 04:25:14'),(11,1,'sukarela','withdrawal',-63000.00,'2025-12-21',NULL,'Pembayaran Belanja: TRX-20251221-ZRUZ',1,'2025-12-21 04:37:32','2025-12-21 04:37:32'),(12,5,'pokok','deposit',150000.00,'2025-12-22','SMP202512220001',NULL,1,'2025-12-21 17:45:11','2025-12-21 17:45:11'),(13,5,'wajib','deposit',100000.00,'2025-12-22','SMP202512220002',NULL,1,'2025-12-21 17:45:20','2025-12-21 17:45:20'),(14,5,'sukarela','deposit',500000.00,'2025-12-22','SMP202512220003',NULL,1,'2025-12-21 17:45:51','2025-12-21 17:45:51');
/*!40000 ALTER TABLE `savings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('sdK8lis62ss3HqSxFKLGAx6xb7SbRJ9OT9jXXiCL',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiNzJtZVJobmQzbEk1SVM5OFJ3aGQ0Qlk3cFE1bkg1SWE4TEpjbkhQSiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly9rb3BlcmFzaS50ZXN0L3NldHRpbmdzL2JhY2t1cCI7czo1OiJyb3V0ZSI7czoxNToic2V0dGluZ3MuYmFja3VwIjt9czozOiJ1cmwiO2E6MDp7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==',1766393296);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'coop_name','KOPERASI SKF','general','text','Nama Koperasi','2025-12-20 21:01:05','2025-12-21 17:57:09'),(2,'coop_address','Kawasan Industri Mitrakarawang (KIM), \r\nJalan Mitra Raya Nomor II Blok F2,  Desa Parungmulya, Kecamatan Ciampel, Karawang - Jawa Barat','general','text','Alamat Koperasi','2025-12-20 21:01:05','2025-12-20 21:42:10'),(3,'coop_phone','081285468206','general','text','Nomor Telepon','2025-12-20 21:01:05','2025-12-20 21:42:10'),(4,'coop_email','spindo.skf@spindo.co.id','general','text','Email Koperasi','2025-12-20 21:01:05','2025-12-20 21:42:10'),(5,'simpanan_pokok_amount','100000','savings','number','Jumlah Simpanan Pokok','2025-12-20 21:01:05','2025-12-20 21:01:05'),(6,'simpanan_wajib_amount','50000','savings','number','Jumlah Simpanan Wajib Bulanan','2025-12-20 21:01:05','2025-12-20 21:01:05'),(7,'loan_interest_rate','1','loan','number','Bunga Pinjaman per Bulan (%)','2025-12-20 21:01:05','2025-12-20 21:01:05'),(8,'max_loan_amount','50000000','loan','number','Maksimal Jumlah Pinjaman','2025-12-20 21:01:05','2025-12-20 21:01:05'),(9,'max_loan_duration','24','loan','number','Maksimal Tenor Pinjaman (bulan)','2025-12-20 21:01:05','2025-12-20 21:01:05'),(10,'shu_jasa_simpanan','30','shu','number','Persentase SHU untuk Jasa Simpanan (%)','2025-12-20 21:01:05','2025-12-20 21:01:05'),(11,'shu_jasa_pinjaman','20','shu','number','Persentase SHU untuk Jasa Pinjaman (%)','2025-12-20 21:01:05','2025-12-20 21:01:05'),(12,'coop_logo','settings/Ej0MeKK3udQUHZiDC8SZ9Wm0sY94l68iFGA6L06i.png','general','text',NULL,'2025-12-20 21:42:10','2025-12-20 21:42:10'),(13,'app_url','http://192.168.110.39/Koperasi/public','general','text',NULL,'2025-12-20 21:42:10','2025-12-20 21:42:10'),(14,'loan_interest_regular','1','loan','text',NULL,'2025-12-20 21:42:10','2025-12-20 21:42:10'),(15,'loan_max_duration','12','loan','text',NULL,'2025-12-20 21:42:10','2025-12-20 21:42:10'),(16,'loan_limit_max','5000000','loan','text',NULL,'2025-12-20 21:42:10','2025-12-20 21:42:10'),(17,'saving_principal','150000','savings','text',NULL,'2025-12-21 02:23:52','2025-12-21 02:23:52'),(18,'saving_mandatory','100000','savings','text',NULL,'2025-12-21 02:23:52','2025-12-21 02:23:52'),(19,'default_credit_limit','500000','general','text',NULL,'2025-12-21 02:23:52','2025-12-21 02:23:52'),(20,'payment_qris_image','settings/Ab0116TrFIopF1WGUrbH2qf19ZQdB0wZ5SNRmduw.png','payment','text',NULL,'2025-12-21 05:32:14','2025-12-21 20:59:22'),(21,'bank_name','BCA','payment','text',NULL,'2025-12-21 05:32:14','2025-12-21 05:32:14'),(22,'bank_account_number','102646952','payment','text',NULL,'2025-12-21 05:32:14','2025-12-21 05:32:14'),(23,'bank_account_name','Koperasi SPINDO KARAWANG','payment','text',NULL,'2025-12-21 05:32:14','2025-12-21 05:32:14'),(24,'qris_image','C:\\Users\\SPINDO_Digitalisasi\\AppData\\Local\\Temp\\php4D04.tmp','general','text',NULL,'2025-12-21 05:32:14','2025-12-21 05:32:14'),(25,'point_earn_rate','10000','commerce','number','Kelipatan belanja untuk 1 poin (Rp)','2025-12-21 06:10:50','2025-12-21 06:10:50'),(26,'point_conversion_rate','1','commerce','number','Nilai tukar 1 poin ke Rupiah','2025-12-21 06:10:50','2025-12-21 06:10:50'),(27,'landing_hero_image','settings/Ck6E4SRxzaIK87ia5FH53JciHpUTrQWsg5orDxv4.png','landing','text',NULL,'2025-12-21 20:26:35','2025-12-21 20:41:47'),(28,'landing_hero_title','Solusi Keuangan Modern untuk Masa Depan Sejahtera','landing','text',NULL,'2025-12-21 20:26:35','2025-12-21 21:43:00'),(29,'landing_hero_subtitle','Bergabunglah dengan ribuan anggota lainnya. Nikmati kemudahan simpan pinjam, belanja hemat, dan bagi hasil yang transparan dalam satu aplikasi terintegrasi.','landing','text',NULL,'2025-12-21 20:26:35','2025-12-21 21:43:00'),(30,'landing_about_text','Kami adalah koperasi modern yang berkomitmen untuk mensejahterakan anggota melalui inovasi teknologi...','landing','text',NULL,'2025-12-21 20:26:35','2025-12-21 21:43:00'),(31,'bank_account','1092545625','payment','text',NULL,'2025-12-21 20:58:56','2025-12-21 21:04:59'),(32,'bank_holder','Koperasi PT. SPINDO - SKF','payment','text',NULL,'2025-12-21 20:58:56','2025-12-21 21:04:59'),(33,'landing_struktur_image','settings/qxjsQ03RCMySmLzuxLIe0ds4d1pUMZdhzu735wCD.png','landing','text',NULL,'2025-12-21 21:43:00','2025-12-21 21:43:00'),(34,'landing_feature1_title',NULL,'landing','text',NULL,'2025-12-21 21:43:00','2025-12-21 21:43:00'),(35,'landing_feature1_desc',NULL,'landing','text',NULL,'2025-12-21 21:43:00','2025-12-21 21:43:00'),(36,'landing_feature2_title',NULL,'landing','text',NULL,'2025-12-21 21:43:00','2025-12-21 21:43:00'),(37,'landing_feature2_desc',NULL,'landing','text',NULL,'2025-12-21 21:43:00','2025-12-21 21:43:00'),(38,'landing_feature3_title',NULL,'landing','text',NULL,'2025-12-21 21:43:00','2025-12-21 21:43:00'),(39,'landing_feature3_desc',NULL,'landing','text',NULL,'2025-12-21 21:43:00','2025-12-21 21:43:00'),(40,'landing_visi','Menjadi mitra terpercaya dalam meningkatkan kesejahteraan karyawan \r\nPT SPINDO Karawang Factory','landing','text',NULL,'2025-12-21 21:43:00','2025-12-21 21:57:12'),(41,'landing_misi',NULL,'landing','text',NULL,'2025-12-21 21:43:00','2025-12-21 21:43:00'),(42,'landing_program_kerja',NULL,'landing','text',NULL,'2025-12-21 21:43:00','2025-12-21 21:43:00'),(43,'landing_about_image','settings/MSxzOv8Mp9utHeogNefla2apGEN8wZIeFCxmbuK0.png','landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 22:37:21'),(44,'landing_about_title',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46'),(45,'landing_about_highlight1_title',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46'),(46,'landing_about_highlight1_desc',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46'),(47,'landing_about_highlight2_title',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46'),(48,'landing_about_highlight2_desc',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46'),(49,'landing_cta_title',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46'),(50,'landing_cta_subtitle',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46'),(51,'landing_footer_desc',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46'),(52,'landing_social_twitter',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46'),(53,'landing_social_facebook',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46'),(54,'landing_social_instagram',NULL,'landing','text',NULL,'2025-12-21 21:47:46','2025-12-21 21:47:46');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_members`
--

DROP TABLE IF EXISTS `team_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `twitter_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_members`
--

LOCK TABLES `team_members` WRITE;
/*!40000 ALTER TABLE `team_members` DISABLE KEYS */;
INSERT INTO `team_members` VALUES (1,'Nata Surya','Wakil Ketua','team/QZXTfQXNtB8oB5G9Hf3eNID23johPFwfQdNMbzqv.png',NULL,NULL,NULL,NULL,NULL,0,'2025-12-21 23:25:53','2025-12-21 23:25:53'),(2,'Annisa Yulianda','Sekertaris','team/laraSJrkHhXcncF35oqmfFWSmhqHOdwMsWJZdwvd.png',NULL,NULL,NULL,NULL,NULL,0,'2025-12-21 23:27:27','2025-12-21 23:27:27');
/*!40000 ALTER TABLE `team_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_items`
--

DROP TABLE IF EXISTS `transaction_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned DEFAULT NULL,
  `quantity` int NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_items_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_items_product_id_foreign` (`product_id`),
  CONSTRAINT `transaction_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transaction_items_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_items`
--

LOCK TABLES `transaction_items` WRITE;
/*!40000 ALTER TABLE `transaction_items` DISABLE KEYS */;
INSERT INTO `transaction_items` VALUES (1,1,2,1,9500.00,9500.00,'2025-12-21 00:15:51','2025-12-21 00:15:51'),(2,1,4,1,2500.00,2500.00,'2025-12-21 00:15:51','2025-12-21 00:15:51'),(3,1,7,1,4000.00,4000.00,'2025-12-21 00:15:51','2025-12-21 00:15:51'),(4,1,10,1,5000.00,5000.00,'2025-12-21 00:15:51','2025-12-21 00:15:51'),(5,1,11,1,12000.00,12000.00,'2025-12-21 00:15:51','2025-12-21 00:15:51'),(6,1,23,2,15000.00,30000.00,'2025-12-21 00:15:51','2025-12-21 00:15:51'),(7,1,24,1,25000.00,25000.00,'2025-12-21 00:15:51','2025-12-21 00:15:51'),(8,1,22,1,22000.00,22000.00,'2025-12-21 00:15:51','2025-12-21 00:15:51'),(9,1,20,1,45000.00,45000.00,'2025-12-21 00:15:51','2025-12-21 00:15:51'),(10,2,2,2,9500.00,19000.00,'2025-12-21 00:16:13','2025-12-21 00:16:13'),(11,2,7,2,4000.00,8000.00,'2025-12-21 00:16:13','2025-12-21 00:16:13'),(12,2,6,1,6000.00,6000.00,'2025-12-21 00:16:13','2025-12-21 00:16:13'),(13,2,3,1,15000.00,15000.00,'2025-12-21 00:16:13','2025-12-21 00:16:13'),(14,3,1,1,11500.00,11500.00,'2025-12-21 00:24:00','2025-12-21 00:24:00'),(15,3,6,1,6000.00,6000.00,'2025-12-21 00:24:00','2025-12-21 00:24:00'),(16,3,2,1,9500.00,9500.00,'2025-12-21 00:24:00','2025-12-21 00:24:00'),(17,3,5,1,22000.00,22000.00,'2025-12-21 00:24:00','2025-12-21 00:24:00'),(18,4,5,1,22000.00,22000.00,'2025-12-21 00:30:26','2025-12-21 00:30:26'),(19,4,10,1,5000.00,5000.00,'2025-12-21 00:30:26','2025-12-21 00:30:26'),(20,4,11,1,12000.00,12000.00,'2025-12-21 00:30:26','2025-12-21 00:30:26'),(21,4,8,1,5500.00,5500.00,'2025-12-21 00:30:26','2025-12-21 00:30:26'),(22,4,6,1,6000.00,6000.00,'2025-12-21 00:30:26','2025-12-21 00:30:26'),(23,5,1,1,11500.00,11500.00,'2025-12-21 00:36:59','2025-12-21 00:36:59'),(24,5,2,1,9500.00,9500.00,'2025-12-21 00:36:59','2025-12-21 00:36:59'),(25,5,7,1,4000.00,4000.00,'2025-12-21 00:36:59','2025-12-21 00:36:59'),(26,5,6,1,6000.00,6000.00,'2025-12-21 00:36:59','2025-12-21 00:36:59'),(27,5,10,1,5000.00,5000.00,'2025-12-21 00:36:59','2025-12-21 00:36:59'),(28,5,11,1,12000.00,12000.00,'2025-12-21 00:36:59','2025-12-21 00:36:59'),(29,5,12,1,85000.00,85000.00,'2025-12-21 00:36:59','2025-12-21 00:36:59'),(30,5,8,1,5500.00,5500.00,'2025-12-21 00:36:59','2025-12-21 00:36:59'),(31,6,18,1,4500.00,4500.00,'2025-12-21 00:42:02','2025-12-21 00:42:02'),(32,6,22,1,22000.00,22000.00,'2025-12-21 00:42:02','2025-12-21 00:42:02'),(33,6,23,1,15000.00,15000.00,'2025-12-21 00:42:02','2025-12-21 00:42:02'),(34,6,19,1,2500.00,2500.00,'2025-12-21 00:42:02','2025-12-21 00:42:02'),(35,6,17,1,110000.00,110000.00,'2025-12-21 00:42:02','2025-12-21 00:42:02'),(36,6,21,1,2000.00,2000.00,'2025-12-21 00:42:02','2025-12-21 00:42:02'),(37,6,24,1,25000.00,25000.00,'2025-12-21 00:42:02','2025-12-21 00:42:02'),(38,6,4,2,2500.00,5000.00,'2025-12-21 00:42:02','2025-12-21 00:42:02'),(39,7,1,1,11500.00,11500.00,'2025-12-21 00:48:43','2025-12-21 00:48:43'),(40,7,2,1,9500.00,9500.00,'2025-12-21 00:48:43','2025-12-21 00:48:43'),(41,7,3,1,15000.00,15000.00,'2025-12-21 00:48:43','2025-12-21 00:48:43'),(42,7,4,1,2500.00,2500.00,'2025-12-21 00:48:43','2025-12-21 00:48:43'),(43,7,5,2,22000.00,44000.00,'2025-12-21 00:48:43','2025-12-21 00:48:43'),(44,7,6,1,6000.00,6000.00,'2025-12-21 00:48:43','2025-12-21 00:48:43'),(45,8,1,1,11500.00,11500.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(46,8,2,1,9500.00,9500.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(47,8,3,1,15000.00,15000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(48,8,4,1,2500.00,2500.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(49,8,5,1,22000.00,22000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(50,8,7,1,4000.00,4000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(51,8,8,1,5500.00,5500.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(52,8,6,1,6000.00,6000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(53,8,9,1,8000.00,8000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(54,8,10,1,5000.00,5000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(55,8,11,1,12000.00,12000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(56,8,12,1,85000.00,85000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(57,8,13,1,38000.00,38000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(58,8,14,1,16500.00,16500.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(59,8,15,1,28000.00,28000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(60,8,16,1,24000.00,24000.00,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(61,9,1,1,11500.00,11500.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(62,9,2,1,9500.00,9500.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(63,9,3,1,15000.00,15000.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(64,9,4,1,2500.00,2500.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(65,9,5,1,22000.00,22000.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(66,9,6,2,6000.00,12000.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(67,9,7,1,4000.00,4000.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(68,9,8,1,5500.00,5500.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(69,9,9,1,8000.00,8000.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(70,9,10,1,5000.00,5000.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(71,9,11,1,12000.00,12000.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(72,9,12,1,85000.00,85000.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(73,9,17,1,110000.00,110000.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(74,9,18,1,4500.00,4500.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(75,9,19,1,2500.00,2500.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(76,9,21,1,2000.00,2000.00,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(77,10,1,1,11500.00,11500.00,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(78,10,2,1,9500.00,9500.00,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(79,10,7,2,4000.00,8000.00,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(80,10,6,1,6000.00,6000.00,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(81,10,5,1,22000.00,22000.00,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(82,10,8,1,5500.00,5500.00,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(83,10,12,1,85000.00,85000.00,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(84,10,11,1,12000.00,12000.00,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(85,10,10,1,5000.00,5000.00,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(86,10,9,1,8000.00,8000.00,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(87,11,18,1,4500.00,4500.00,'2025-12-21 01:33:58','2025-12-21 01:33:58'),(88,11,25,1,11000.00,11000.00,'2025-12-21 01:33:58','2025-12-21 01:33:58'),(89,11,23,1,15000.00,15000.00,'2025-12-21 01:33:58','2025-12-21 01:33:58'),(90,12,1,1,11500.00,11500.00,'2025-12-21 02:06:46','2025-12-21 02:06:46'),(91,12,2,1,9500.00,9500.00,'2025-12-21 02:06:46','2025-12-21 02:06:46'),(92,13,3,1,15000.00,15000.00,'2025-12-21 02:18:40','2025-12-21 02:18:40'),(93,13,4,1,2500.00,2500.00,'2025-12-21 02:18:40','2025-12-21 02:18:40'),(94,13,8,1,5500.00,5500.00,'2025-12-21 02:18:40','2025-12-21 02:18:40'),(95,14,1,2,11500.00,23000.00,'2025-12-21 04:24:11','2025-12-21 04:24:11'),(96,14,2,2,9500.00,19000.00,'2025-12-21 04:24:11','2025-12-21 04:24:11'),(97,14,3,2,15000.00,30000.00,'2025-12-21 04:24:11','2025-12-21 04:24:11'),(98,14,4,1,2500.00,2500.00,'2025-12-21 04:24:11','2025-12-21 04:24:11'),(99,14,5,1,22000.00,22000.00,'2025-12-21 04:24:11','2025-12-21 04:24:11'),(100,14,6,1,6000.00,6000.00,'2025-12-21 04:24:11','2025-12-21 04:24:11'),(101,14,7,2,4000.00,8000.00,'2025-12-21 04:24:11','2025-12-21 04:24:11'),(102,15,1,1,11500.00,11500.00,'2025-12-21 04:25:14','2025-12-21 04:25:14'),(103,15,2,1,9500.00,9500.00,'2025-12-21 04:25:14','2025-12-21 04:25:14'),(104,15,3,1,15000.00,15000.00,'2025-12-21 04:25:14','2025-12-21 04:25:14'),(105,15,4,1,2500.00,2500.00,'2025-12-21 04:25:14','2025-12-21 04:25:14'),(106,15,5,1,22000.00,22000.00,'2025-12-21 04:25:14','2025-12-21 04:25:14'),(107,16,1,1,11500.00,11500.00,'2025-12-21 04:32:11','2025-12-21 04:32:11'),(108,16,2,1,9500.00,9500.00,'2025-12-21 04:32:11','2025-12-21 04:32:11'),(109,16,3,1,15000.00,15000.00,'2025-12-21 04:32:11','2025-12-21 04:32:11'),(110,16,4,1,2500.00,2500.00,'2025-12-21 04:32:11','2025-12-21 04:32:11'),(111,16,5,1,22000.00,22000.00,'2025-12-21 04:32:11','2025-12-21 04:32:11'),(112,16,6,1,6000.00,6000.00,'2025-12-21 04:32:11','2025-12-21 04:32:11'),(113,16,7,1,4000.00,4000.00,'2025-12-21 04:32:11','2025-12-21 04:32:11'),(114,17,1,1,11500.00,11500.00,'2025-12-21 04:37:32','2025-12-21 04:37:32'),(115,17,3,2,15000.00,30000.00,'2025-12-21 04:37:32','2025-12-21 04:37:32'),(116,17,4,1,2500.00,2500.00,'2025-12-21 04:37:32','2025-12-21 04:37:32'),(117,17,2,2,9500.00,19000.00,'2025-12-21 04:37:32','2025-12-21 04:37:32'),(118,18,18,2,4500.00,9000.00,'2025-12-21 07:58:02','2025-12-21 07:58:02'),(119,18,25,1,11000.00,11000.00,'2025-12-21 07:58:02','2025-12-21 07:58:02'),(128,23,18,3,4500.00,13500.00,'2025-12-21 08:11:14','2025-12-21 08:11:14'),(129,23,25,3,11000.00,33000.00,'2025-12-21 08:11:14','2025-12-21 08:11:14');
/*!40000 ALTER TABLE `transaction_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `cashier_id` bigint unsigned DEFAULT NULL,
  `type` enum('offline','online') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'offline',
  `status` enum('pending','paid','processing','completed','cancelled','credit') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `paid_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `change_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transactions_invoice_number_unique` (`invoice_number`),
  KEY `transactions_user_id_foreign` (`user_id`),
  KEY `transactions_cashier_id_foreign` (`cashier_id`),
  CONSTRAINT `transactions_cashier_id_foreign` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,'TRX-20251221-ARUB',NULL,5,'offline','completed','cash',155000.00,160000.00,5000.00,NULL,'2025-12-21 00:15:51','2025-12-21 00:15:51'),(2,'TRX-20251221-YF5Q',NULL,5,'offline','completed','qr',48000.00,48000.00,0.00,NULL,'2025-12-21 00:16:13','2025-12-21 00:16:13'),(3,'TRX-20251221-MTYP',NULL,5,'offline','completed','qr',49000.00,49000.00,0.00,NULL,'2025-12-21 00:24:00','2025-12-21 00:24:00'),(4,'TRX-20251221-JUDI',NULL,5,'offline','completed','cash',50500.00,60000.00,9500.00,NULL,'2025-12-21 00:30:26','2025-12-21 00:30:26'),(5,'TRX-20251221-84TB',NULL,5,'offline','completed','qr',138500.00,138500.00,0.00,NULL,'2025-12-21 00:36:59','2025-12-21 00:36:59'),(6,'TRX-20251221-KXMO',NULL,5,'offline','completed','cash',186000.00,200000.00,14000.00,NULL,'2025-12-21 00:42:02','2025-12-21 00:42:02'),(7,'TRX-20251221-IIFN',NULL,5,'offline','completed','qr',88500.00,88500.00,0.00,NULL,'2025-12-21 00:48:43','2025-12-21 00:48:43'),(8,'TRX-20251221-119C',NULL,5,'offline','completed','qr',292500.00,292500.00,0.00,NULL,'2025-12-21 00:49:42','2025-12-21 00:49:42'),(9,'TRX-20251221-NIWO',NULL,5,'offline','completed','qr',311000.00,311000.00,0.00,NULL,'2025-12-21 00:52:36','2025-12-21 00:52:36'),(10,'TRX-20251221-CE5H',NULL,5,'offline','completed','qris',172500.00,172500.00,0.00,NULL,'2025-12-21 01:06:56','2025-12-21 01:06:56'),(11,'INV-20251221-E3OB',5,1,'online','completed','cash_pickup',30500.00,30500.00,0.00,NULL,'2025-12-21 01:33:58','2025-12-21 07:24:34'),(12,'TRX-20251221-BSJ6',6,5,'offline','completed','saldo',21000.00,21000.00,0.00,NULL,'2025-12-21 02:06:46','2025-12-21 02:06:46'),(13,'TRX-20251221-FUHI',3,5,'offline','completed','kredit',23000.00,23000.00,0.00,'Dilunasi via CASH pada 21/12/2025 09:42 oleh Admin Koperasi','2025-12-21 02:18:40','2025-12-21 02:42:36'),(14,'TRX-20251221-MQKV',3,1,'offline','credit','kredit',110500.00,0.00,0.00,NULL,'2025-12-21 04:24:11','2025-12-21 04:24:11'),(15,'TRX-20251221-GIVX',3,1,'offline','completed','saldo',60500.00,60500.00,0.00,NULL,'2025-12-21 04:25:14','2025-12-21 04:25:14'),(16,'TRX-20251221-N9GP',6,1,'offline','credit','kredit',70500.00,0.00,0.00,NULL,'2025-12-21 04:32:11','2025-12-21 04:32:11'),(17,'TRX-20251221-ZRUZ',3,1,'offline','completed','saldo',63000.00,63000.00,0.00,NULL,'2025-12-21 04:37:32','2025-12-21 04:37:32'),(18,'INV-20251221-HGRB',1,NULL,'online','pending','transfer',20000.00,0.00,0.00,'[AMBIL SENDIRI]','2025-12-21 07:58:02','2025-12-21 07:58:02'),(23,'INV-20251221-KUIO',3,NULL,'online','credit','kredit',46500.00,0.00,0.00,'[AMBIL SENDIRI]','2025-12-21 08:11:14','2025-12-21 08:11:14');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('member','admin','pengurus') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'member',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin Koperasi','admin@koperasi.com',NULL,'$2y$12$5fre9eOE0RySRiJiX6HZeuQcVTZ78jUnN4PInI3G2XU3OMSUZeGPW','admin','081234567890',NULL,1,NULL,'2025-12-20 21:01:05','2025-12-20 21:28:20'),(2,'Pengurus Koperasi','pengurus@koperasi.com',NULL,'$2y$12$duzv8dQo/L9AXhy5bYsmGeDzATIOtxPs2JpDxNZSm4v/jOvyhHX8a','pengurus','081234567891',NULL,1,NULL,'2025-12-20 21:01:05','2025-12-20 21:01:05'),(3,'Nata Surya Permana','nata@koperasi.com',NULL,'$2y$12$LCzNyXKqRssPbs2qJAYHu.ar4jZQazu2oxyE65ZZ9ZqvUSJBhAM6S','member','081234567892',NULL,1,NULL,'2025-12-20 21:01:05','2025-12-20 21:35:47'),(5,'Ngafif Usman','ngafif@koperasi.com',NULL,'$2y$12$xMMdYYU9IfEpei28BLZ1h.Y91MxXaz6p3zG1XsfyVJdFCc958mR1u','pengurus','084656522663',NULL,1,'0XnuoZSpjROHT0r5f56W6LO3F4wSdSpXuzRcjxSByrLhqTLkR1RHMg62Osx3','2025-12-20 21:39:24','2025-12-20 23:58:30'),(6,'Agus Zatnika','agus@koperasi.com',NULL,'$2y$12$sAmYIw6MByLDLCI6GQhzWuZRJM5HKubsWb/Eqf.N01EUAEV6ieR1C','member',NULL,NULL,1,NULL,'2025-12-20 23:05:44','2025-12-20 23:30:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vouchers`
--

DROP TABLE IF EXISTS `vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vouchers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('fixed','percentage') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed',
  `value` decimal(15,2) NOT NULL,
  `min_purchase` decimal(15,2) NOT NULL DEFAULT '0.00',
  `usage_limit` int DEFAULT NULL,
  `used_count` int NOT NULL DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vouchers_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_programs`
--

DROP TABLE IF EXISTS `work_programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_programs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'blue',
  `order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_programs`
--

LOCK TABLES `work_programs` WRITE;
/*!40000 ALTER TABLE `work_programs` DISABLE KEYS */;
INSERT INTO `work_programs` VALUES (1,'Digitalisasi Layan Koperasi','Memberikan pelayanan akuntable dan transparan','programs/J0A57hhYAK0mAuWYN5gXPYtmOdufejVHW6WLWsbd.png','green',1,'2025-12-22 01:19:10','2025-12-22 01:19:10');
/*!40000 ALTER TABLE `work_programs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-22 15:48:22
