@extends('layouts.app')

@section('title', 'Buat Pembelian Baru')

@section('content')
<div class="max-w-5xl mx-auto space-y-6">
    <div class="flex items-center gap-4 mb-6">
        <a href="{{ route('purchases.index') }}" class="btn-secondary-sm">
            ← Kembali
        </a>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Transaksi Pembelian Baru</h1>
    </div>

    <form action="{{ route('purchases.store') }}" method="POST" id="purchaseForm" class="space-y-6">
        @csrf
        
        <!-- Header Info -->
        <div class="glass-card p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
                <label class="form-label">No. Referensi (PO)</label>
                <input type="text" name="reference_number" class="form-input bg-gray-50" value="{{ old('reference_number', $poNumber) }}" readonly>
            </div>
            <div>
                <label class="form-label">Tanggal Pembelian</label>
                <input type="date" name="purchase_date" class="form-input" value="{{ old('purchase_date', date('Y-m-d')) }}" required>
            </div>
            <div>
                <label class="form-label">Supplier <span class="text-red-500">*</span></label>
                <select name="supplier_id" class="form-input" required>
                    <option value="">-- Pilih Supplier --</option>
                    @foreach($suppliers as $supplier)
                    <option value="{{ $supplier->id }}" {{ old('supplier_id') == $supplier->id ? 'selected' : '' }}>
                        {{ $supplier->name }}
                    </option>
                    @endforeach
                </select>
                <div class="mt-1 text-xs text-right">
                    <a href="{{ route('suppliers.create') }}" class="text-primary-600 hover:underline">+ Tambah Supplier Baru</a>
                </div>
            </div>
        </div>

        <!-- Barcode Scanner -->
        <div class="glass-card p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800">
            <div class="flex items-center gap-4">
                <div class="p-3 bg-blue-100 dark:bg-blue-800 rounded-full text-blue-600 dark:text-blue-300">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"></path></svg>
                </div>
                <div class="flex-1">
                    <label class="form-label mb-1">Scan Barcode / Kode Produk</label>
                    <input type="text" id="barcodeInput" class="form-input text-lg font-mono focus:ring-blue-500" placeholder="Scan barcode disini..." autofocus>
                    <p class="text-xs text-gray-500 mt-1">Tekan Enter setelah scan (otomatis pada scanner).</p>
                </div>
            </div>
        </div>

        <!-- Items Table -->
        <div class="glass-card overflow-hidden">
            <div class="p-4 bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                <h3 class="font-bold text-gray-900 dark:text-white">Item Pembelian</h3>
                <button type="button" onclick="addItem()" class="btn-primary-sm">
                    + Tambah Produk Manual
                </button>
            </div>
            
            <div class="overflow-x-auto">
                <table class="table-modern w-full" id="itemsTable">
                    <thead>
                        <tr>
                            <th style="width: 40%">Produk</th>
                            <th style="width: 15%">Qty</th>
                            <th style="width: 20%">Harga Beli (Satuan)</th>
                            <th style="width: 20%" class="text-right">Subtotal</th>
                            <th style="width: 5%"></th>
                        </tr>
                    </thead>
                    <tbody id="itemsBody">
                        <!-- Items will be added here via JS -->
                    </tbody>
                    <tfoot class="bg-gray-50 dark:bg-gray-700/50">
                        <tr>
                            <td colspan="3" class="text-right font-bold py-3 px-4">TOTAL</td>
                            <td class="text-right font-bold py-3 px-4 text-primary-600 text-lg" id="grandTotal">Rp 0</td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <div class="glass-card p-6">
            <label class="form-label">Catatan</label>
            <textarea name="note" rows="2" class="form-input" placeholder="Opsional...">{{ old('note') }}</textarea>
        </div>

        <div class="flex justify-end gap-3 pt-4">
            <a href="{{ route('purchases.index') }}" class="btn-secondary">Batal</a>
            <button type="submit" class="btn-primary">Simpan Transaksi</button>
        </div>
    </form>
</div>

<!-- Template for Row -->
<template id="itemRowTemplate">
    <tr class="item-row">
        <td class="p-2">
            <select name="items[INDEX][product_id]" class="form-input product-select" required onchange="updateProductPrice(this)">
                <option value="">Pilih Produk...</option>
                @foreach($products as $product)
                <option value="{{ $product->id }}" data-cost="{{ $product->cost }}" data-code="{{ $product->code }}">{{ $product->name }} ({{ $product->code }})</option>
                @endforeach
            </select>
        </td>
        <td class="p-2">
            <input type="number" name="items[INDEX][quantity]" class="form-input qty-input" min="1" value="1" required oninput="calculateRow(this)">
        </td>
        <td class="p-2">
            <input type="number" name="items[INDEX][cost]" class="form-input cost-input" min="0" value="0" required oninput="calculateRow(this)">
        </td>
        <td class="p-2 text-right font-medium subtotal-display">
            Rp 0
        </td>
        <td class="p-2 text-center">
            <button type="button" onclick="removeItem(this)" class="text-red-500 hover:text-red-700">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
            </button>
        </td>
    </tr>
</template>

@push('scripts')
<script>
    let itemIndex = 0;
    
    // Create a map of product codes to IDs for faster lookup
    const productsMap = {
        @foreach($products as $product)
        "{{ $product->code }}": "{{ $product->id }}",
        @endforeach
    };

    function addItem(productId = null) {
        const template = document.getElementById('itemRowTemplate');
        const clone = template.content.cloneNode(true);
        const tbody = document.getElementById('itemsBody');
        
        // Update names with unique index
        clone.querySelectorAll('[name*="INDEX"]').forEach(el => {
            el.name = el.name.replace('INDEX', itemIndex);
        });
        
        // Set product if provided via scan
        if (productId) {
            const select = clone.querySelector('.product-select');
            select.value = productId;
            // We need to trigger updateProductPrice significantly after append
            // but setting value here is safe before append
        }

        tbody.appendChild(clone);
        
        // Trigger calc and price update if product set
        if (productId) {
            const lastRow = tbody.lastElementChild;
            const select = lastRow.querySelector('.product-select');
            updateProductPrice(select);
        }

        itemIndex++;
        calculateTotal();
    }

    function removeItem(btn) {
        btn.closest('tr').remove();
        calculateTotal();
    }

    function updateProductPrice(select) {
        const option = select.selectedOptions[0];
        const cost = option.getAttribute('data-cost') || 0;
        const row = select.closest('tr');
        
        row.querySelector('.cost-input').value = cost;
        calculateRow(select);
    }

    function calculateRow(input) {
        const row = input.closest('tr');
        const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
        const cost = parseFloat(row.querySelector('.cost-input').value) || 0;
        const subtotal = qty * cost;

        row.querySelector('.subtotal-display').textContent = 'Rp ' + new Intl.NumberFormat('id-ID').format(subtotal);
        calculateTotal();
    }

    function calculateTotal() {
        let total = 0;
        document.querySelectorAll('.item-row').forEach(row => {
            const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
            const cost = parseFloat(row.querySelector('.cost-input').value) || 0;
            total += (qty * cost);
        });

        document.getElementById('grandTotal').textContent = 'Rp ' + new Intl.NumberFormat('id-ID').format(total);
    }
    
    // Barcode Scanner Logic
    document.getElementById('barcodeInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            const barcode = this.value.trim();
            if (!barcode) return;
            
            const productId = productsMap[barcode];
            
            if (productId) {
                // Check if product needed to check if already exists
                let existingRow = null;
                document.querySelectorAll('.product-select').forEach(select => {
                    if (select.value === productId) {
                        existingRow = select.closest('tr');
                    }
                });
                
                if (existingRow) {
                    // Increment qty
                    const qtyInput = existingRow.querySelector('.qty-input');
                    qtyInput.value = parseInt(qtyInput.value) + 1;
                    calculateRow(qtyInput);
                    
                    // Flash row to indicate update
                    existingRow.classList.add('bg-green-50', 'dark:bg-green-900/20');
                    setTimeout(() => {
                        existingRow.classList.remove('bg-green-50', 'dark:bg-green-900/20');
                    }, 500);
                } else {
                    // Add new row
                    addItem(productId);
                }
                
                // Success feedback
                this.value = '';
                // Optional: Play sound or visual indicator
            } else {
                alert('Produk dengan kode ' + barcode + ' tidak ditemukan!');
                this.select();
            }
        }
    });

    // Add initial row if empty
    document.addEventListener('DOMContentLoaded', () => {
        // addItem(); // Don't add empty row automatically if we want scan-first workflow, 
                     // but user might want manual input. Let's keep it clean for scanning, 
                     // or maybe add empty row only if no items.
                     // Let's NOT add initial row to keep it clean for scanner users.
    });
</script>
@endpush
@endsection
