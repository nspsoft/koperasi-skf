<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class SettingController extends Controller
{
    /**
     * Display general settings.
     */
    public function index()
    {
        // Get all settings indexed by key for easy access in view
        $settings = Setting::all()->pluck('value', 'key');

        return view('settings.index', compact('settings'));
    }

    /**
     * Update settings.
     */
    public function update(Request $request)
    {
        $data = $request->except(['_token', 'logo', 'qris_image', 'hero_image', 'doc_logo_1', 'doc_logo_2']);

        try {
            DB::beginTransaction();

            // Handle Logo Upload specifically
            if ($request->hasFile('logo')) {
                $path = $request->file('logo')->store('settings', 'public');
                Setting::updateOrCreate(
                    ['key' => 'coop_logo'],
                    ['value' => $path, 'group' => 'general']
                );
            }

            // Handle Document Logo 1 Upload
            if ($request->hasFile('doc_logo_1')) {
                $path = $request->file('doc_logo_1')->store('settings', 'public');
                Setting::updateOrCreate(
                    ['key' => 'doc_logo_1'],
                    ['value' => $path, 'group' => 'document']
                );
            }

            // Handle Document Logo 2 Upload
            if ($request->hasFile('doc_logo_2')) {
                $path = $request->file('doc_logo_2')->store('settings', 'public');
                Setting::updateOrCreate(
                    ['key' => 'doc_logo_2'],
                    ['value' => $path, 'group' => 'document']
                );
            }

            // Handle QRIS Image Upload
            if ($request->hasFile('qris_image')) {
                $path = $request->file('qris_image')->store('settings', 'public');
                Setting::updateOrCreate(
                    ['key' => 'payment_qris_image'],
                    ['value' => $path, 'group' => 'payment']
                );
            }

            // Handle Landing Page Hero Image Upload
            if ($request->hasFile('hero_image')) {
                $path = $request->file('hero_image')->store('settings', 'public');
                Setting::updateOrCreate(
                    ['key' => 'landing_hero_image'],
                    ['value' => $path, 'group' => 'landing']
                );
            }

            // Loop through other fields
            foreach ($data as $key => $value) {
                Setting::updateOrCreate(
                    ['key' => $key],
                    [
                        'value' => $value,
                        'group' => $this->determineGroup($key)
                    ]
                );
            }

            DB::commit();

            // Clear all caches to ensure settings update immediately
            \Cache::flush();
            \Artisan::call('cache:clear');

            return redirect()->back()->with('success', 'Pengaturan berhasil disimpan.');

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Gagal menyimpan pengaturan: ' . $e->getMessage());
        }
    }

    /**
     * Helper to determine group key
     */
    private function determineGroup($key)
    {
        if (str_starts_with($key, 'loan_')) return 'loan';
        if (str_starts_with($key, 'saving_')) return 'savings';
        if (str_starts_with($key, 'bank_')) return 'payment';
        return 'general';
    }
}
