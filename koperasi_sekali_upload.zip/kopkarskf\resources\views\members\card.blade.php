<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Anggota - {{ $member->user->name }}</title>
    <!-- Tailwind via CDN for effortless print styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- QR Code Library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700&display=swap');

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f3f4f6;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        /* ID Card Format (ID-1) */
        .id-card {
            width: 85.6mm;
            height: 53.98mm;
            position: relative;
            overflow: hidden;
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            color: white;
            border-radius: 8px; /* Slightly rounded for web preview */
        }

        /* Print Settings */
        @media print {
            @page {
                size: landscape;
                margin: 0;
            }
            body {
                background-color: white;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
            .no-print {
                display: none;
            }
            .id-card {
                box-shadow: none;
                border-radius: 4px; /* Sharper for print */
            }
        }
        
        .pattern-overlay {
            background-image: radial-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px);
            background-size: 10px 10px;
        }
    </style>
</head>
<body class="flex flex-col items-center justify-center min-h-screen p-4">

    <!-- Actions -->
    <div class="no-print mb-8 flex gap-4">
        <button onclick="window.print()" class="px-6 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition font-medium flex items-center">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path>
            </svg>
            Cetak Kartu
        </button>
        <button onclick="window.close()" class="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg shadow hover:bg-gray-300 transition font-medium">
            Tutup
        </button>
    </div>

    <!-- ID Card Front -->
    <div class="id-card flex flex-col relative">
        <!-- Background Pattern -->
        <div class="absolute inset-0 pattern-overlay opacity-30"></div>
        
        <!-- Decorative Shapes -->
        <div class="absolute -top-10 -right-10 w-48 h-48 bg-white/10 rounded-full blur-2xl"></div>
        <div class="absolute -bottom-10 -left-10 w-32 h-32 bg-blue-900/30 rounded-full blur-xl"></div>

        <!-- Header -->
        <div class="relative z-10 px-5 pt-4 flex justify-between items-start">
            <div class="flex items-center gap-2">
                <!-- Logo Layout -->
                @php
                    $logo = \App\Models\Setting::get('coop_logo');
                    $coopName = \App\Models\Setting::get('coop_name', 'SPINDO KARAWANG FACTORY');
                @endphp
                
                <div class="w-8 h-8 bg-white rounded-lg flex items-center justify-center text-blue-700 overflow-hidden">
                    @if($logo)
                        <img src="{{ Storage::url($logo) }}" class="w-full h-full object-contain p-0.5">
                    @else
                        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                             <path d="M12 2L1 21h22L12 2zm0 4l7.53 13H4.47L12 6z"/>
                        </svg>
                    @endif
                </div>
                <div>
                    <h1 class="text-[10px] font-bold leading-tight tracking-wide text-blue-100 uppercase max-w-[180px]">{{ $coopName }}</h1>
                    <h2 class="text-[8px] text-blue-200 uppercase tracking-widest mt-0.5">Member Card</h2>
                </div>
            </div>
            <div class="test-right">
                <p class="text-[8px] text-blue-200 font-mono">ID: {{ $member->member_id }}</p>
            </div>
        </div>

        <!-- Content -->
        <div class="relative z-10 px-5 mt-4 flex items-end gap-4">
            <!-- Photo Frame -->
            <div class="relative">
                <div class="w-20 h-24 bg-gray-200 rounded-lg border-2 border-white/50 shadow-lg overflow-hidden relative">
                     @if($member->photo)
                        <img src="{{ Storage::url($member->photo) }}" class="w-full h-full object-cover">
                    @else
                        <div class="w-full h-full bg-gray-300 flex items-center justify-center text-gray-500">
                             <svg class="w-10 h-10" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                        </div>
                    @endif
                </div>
                <!-- Status Badge -->
                 <div class="absolute -bottom-2 -right-2 bg-emerald-500 text-white text-[8px] font-bold px-1.5 py-0.5 rounded shadow-sm border border-white">
                    AKTIF
                </div>
            </div>

            <!-- Details -->
            <div class="flex-1 pb-1">
                <h3 class="text-lg font-bold leading-tight">{{ strtoupper($member->user->name) }}</h3>
                <p class="text-[10px] text-blue-100 mb-2">{{ $member->position ?? 'Anggota' }}</p>

                <div class="grid grid-cols-2 gap-x-2 gap-y-1 text-[9px] text-blue-50 mt-1">
                    <div>
                        <span class="block opacity-60 text-[7px] uppercase">ID Anggota</span>
                        <span class="font-mono font-semibold tracking-wide">{{ $member->member_id }}</span>
                    </div>
                    <div>
                        <span class="block opacity-60 text-[7px] uppercase">Bergabung</span>
                        <span>{{ \Carbon\Carbon::parse($member->join_date)->format('d M Y') }}</span>
                    </div>
                </div>
            </div>

            <!-- QR Code -->
            <div class="bg-white p-1 rounded-lg shadow-sm mb-1">
                <div id="qrcode" class="w-12 h-12"></div>
            </div>
        </div>

        <!-- Footer -->
        <div class="mt-auto relative z-10 bg-blue-900/40 backdrop-blur-sm h-8 flex items-center px-5 border-t border-white/10 w-full justify-between">
             <p class="text-[7px] text-blue-200 tracking-wider">PT. SPINDO KARAWANG FACTORY</p>
             <p class="text-[7px] text-blue-200 font-mono">valid thru: forever</p>
        </div>
    </div>

    <script>
        // Generate QR Code
        new QRCode(document.getElementById("qrcode"), {
            text: "{{ $member->member_id }}",
            width: 48,
            height: 48,
            colorDark : "#000000",
            colorLight : "#ffffff",
            correctLevel : QRCode.CorrectLevel.H
        });
    </script>
</body>
</html>
