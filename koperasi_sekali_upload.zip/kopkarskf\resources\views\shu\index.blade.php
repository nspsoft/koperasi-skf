@extends('layouts.app')

@section('title', __('messages.titles.shu'))

@section('content')
<div class="max-w-7xl mx-auto space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Sisa Hasil Usaha (SHU)</h1>
            <p class="text-gray-600 dark:text-gray-400 mt-1">Kelola pembagian SHU tahunan sesuai UU Perkoperasian.</p>
        </div>
        <a href="{{ route('shu.calculator') }}" class="btn-primary flex items-center gap-2">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
            Konfigurasi SHU
        </a>
    </div>

    <!-- Year Filter -->
    <div class="glass-card-solid p-4">
        <div class="flex flex-wrap gap-4 items-end">
            <div class="flex-1 min-w-[200px]">
                <label class="form-label">Pilih Tahun</label>
                <select class="form-input" onchange="window.location.href='{{ route('shu.index') }}?year='+this.value">
                    @if($availableYears->isEmpty())
                    <option value="{{ date('Y') }}">{{ date('Y') }} (Belum ada data)</option>
                    @else
                    @foreach($availableYears as $y)
                    <option value="{{ $y }}" {{ $year == $y ? 'selected' : '' }}>{{ $y }}</option>
                    @endforeach
                    @endif
                </select>
            </div>
            @if($setting && $distributions->isNotEmpty())
            <a href="{{ route('shu.print-report', ['year' => $year]) }}" target="_blank" class="btn-secondary flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
                PDF
            </a>
            <a href="{{ route('shu.export', ['year' => $year]) }}" class="btn-secondary flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                Excel
            </a>
            @endif
            @if($setting && $setting->status === 'calculated')
            <form action="{{ route('shu.distribute') }}" method="POST" class="inline">
                @csrf
                <input type="hidden" name="year" value="{{ $year }}">
                <button type="submit" class="btn-success" onclick="return confirm('Tandai semua SHU tahun {{ $year }} sebagai sudah didistribusikan?')">
                    ✓ Tandai Sudah Dibagikan
                </button>
            </form>
            @endif
        </div>
    </div>

    @if($setting)
    <!-- Summary Cards -->
    <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        <div class="glass-card p-4 col-span-2">
            <p class="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Total SHU {{ $year }}</p>
            <p class="text-2xl font-bold text-gray-900 dark:text-white mt-1">Rp {{ number_format($setting->total_shu_pool, 0, ',', '.') }}</p>
            <span class="badge badge-{{ $setting->status_color }} mt-2">{{ $setting->status_label }}</span>
        </div>
        <div class="glass-card p-4 border-l-4 border-red-500">
            <p class="text-xs text-gray-500 uppercase">Dana Cadangan</p>
            <p class="text-lg font-bold text-red-600 dark:text-red-400">{{ $setting->persen_cadangan }}%</p>
            <p class="text-xs text-gray-500">Rp {{ number_format($setting->pool_cadangan, 0, ',', '.') }}</p>
        </div>
        <div class="glass-card p-4 border-l-4 border-green-500">
            <p class="text-xs text-gray-500 uppercase">Jasa Modal</p>
            <p class="text-lg font-bold text-green-600 dark:text-green-400">{{ $setting->persen_jasa_modal }}%</p>
            <p class="text-xs text-gray-500">Rp {{ number_format($setting->pool_jasa_modal, 0, ',', '.') }}</p>
        </div>
        <div class="glass-card p-4 border-l-4 border-blue-500">
            <p class="text-xs text-gray-500 uppercase">Jasa Usaha</p>
            <p class="text-lg font-bold text-blue-600 dark:text-blue-400">{{ $setting->persen_jasa_usaha }}%</p>
            <p class="text-xs text-gray-500">Rp {{ number_format($setting->pool_jasa_usaha, 0, ',', '.') }}</p>
        </div>
        <div class="glass-card p-4 border-l-4 border-purple-500">
            <p class="text-xs text-gray-500 uppercase">Pengurus</p>
            <p class="text-lg font-bold text-purple-600 dark:text-purple-400">{{ $setting->persen_pengurus }}%</p>
            <p class="text-xs text-gray-500">Rp {{ number_format($setting->pool_pengurus, 0, ',', '.') }}</p>
        </div>
        <div class="glass-card p-4 border-l-4 border-amber-500">
            <p class="text-xs text-gray-500 uppercase">Karyawan</p>
            <p class="text-lg font-bold text-amber-600 dark:text-amber-400">{{ $setting->persen_karyawan }}%</p>
            <p class="text-xs text-gray-500">Rp {{ number_format($setting->pool_karyawan, 0, ',', '.') }}</p>
        </div>
        <div class="glass-card p-4 border-l-4 border-pink-500">
            <p class="text-xs text-gray-500 uppercase">Lainnya</p>
            <p class="text-lg font-bold text-pink-600 dark:text-pink-400">{{ $setting->persen_pendidikan + $setting->persen_sosial + $setting->persen_pembangunan }}%</p>
            <p class="text-xs text-gray-500">Rp {{ number_format($setting->pool_pendidikan + $setting->pool_sosial + $setting->pool_pembangunan, 0, ',', '.') }}</p>
        </div>
    </div>

    <!-- Member Highlight -->
    <div class="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/30 dark:to-blue-900/30 border border-green-100 dark:border-green-800 rounded-xl p-5">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-600 dark:text-gray-400">Total SHU untuk Anggota (Jasa Modal + Jasa Usaha)</p>
                <p class="text-3xl font-bold text-primary-600 dark:text-primary-400">Rp {{ number_format($setting->pool_anggota, 0, ',', '.') }}</p>
            </div>
            <div class="text-right">
                <p class="text-sm text-gray-600 dark:text-gray-400">Jumlah Penerima</p>
                <p class="text-3xl font-bold text-gray-900 dark:text-white">{{ $distributions->count() }}</p>
            </div>
        </div>
    </div>
    @endif

    <!-- Distribution Table -->
    <div class="glass-card-solid overflow-hidden">
        <div class="p-4 border-b border-gray-100 dark:border-gray-700">
            <h3 class="text-lg font-bold text-gray-900 dark:text-white">Rincian SHU per Anggota - Tahun {{ $year }}</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="table-modern">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Anggota</th>
                        <th class="text-right">Saldo Simpanan</th>
                        <th class="text-right">Total Transaksi</th>
                        <th class="text-right">SHU Jasa Modal</th>
                        <th class="text-right">SHU Jasa Usaha</th>
                        <th class="text-right">Total SHU</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($distributions as $index => $dist)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>
                            <div class="flex items-center gap-2">
                                <div class="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary-600 dark:text-primary-400 font-semibold text-sm">
                                    {{ strtoupper(substr($dist->member->user->name ?? '?', 0, 1)) }}
                                </div>
                                <div>
                                    <span class="font-medium text-gray-900 dark:text-white">{{ $dist->member->user->name ?? '-' }}</span>
                                    <div class="text-xs text-gray-500">{{ $dist->member->member_id ?? '' }}</div>
                                </div>
                            </div>
                        </td>
                        <td class="text-right text-gray-600 dark:text-gray-400">Rp {{ number_format($dist->total_savings, 0, ',', '.') }}</td>
                        <td class="text-right text-gray-600 dark:text-gray-400">Rp {{ number_format($dist->total_transactions, 0, ',', '.') }}</td>
                        <td class="text-right text-green-600 dark:text-green-400">Rp {{ number_format($dist->shu_savings, 0, ',', '.') }}</td>
                        <td class="text-right text-blue-600 dark:text-blue-400">Rp {{ number_format($dist->shu_transactions, 0, ',', '.') }}</td>
                        <td class="text-right font-bold text-gray-900 dark:text-white">Rp {{ number_format($dist->total_shu, 0, ',', '.') }}</td>
                        <td>
                            <div class="flex items-center gap-2">
                                <span class="badge badge-{{ $dist->status_color }}">{{ $dist->status_label }}</span>
                                <a href="{{ route('shu.print-slip', $dist->id) }}" target="_blank" class="btn-icon text-gray-500 hover:text-primary-600" title="Cetak Slip">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
                                </a>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" class="text-center py-12">
                            <svg class="w-12 h-12 mx-auto text-gray-400 dark:text-gray-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
                            </svg>
                            <p class="text-gray-500 dark:text-gray-400 font-medium">Belum ada perhitungan SHU untuk tahun {{ $year }}.</p>
                            <a href="{{ route('shu.calculator', ['year' => $year]) }}" class="text-primary-600 hover:underline mt-2 inline-block">Konfigurasi & Hitung SHU →</a>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
                @if($distributions->isNotEmpty())
                <tfoot class="bg-gray-50 dark:bg-gray-700/50">
                    <tr class="font-bold">
                        <td colspan="4" class="text-right">TOTAL</td>
                        <td class="text-right text-green-600 dark:text-green-400">Rp {{ number_format($distributions->sum('shu_savings'), 0, ',', '.') }}</td>
                        <td class="text-right text-blue-600 dark:text-blue-400">Rp {{ number_format($distributions->sum('shu_transactions'), 0, ',', '.') }}</td>
                        <td class="text-right text-gray-900 dark:text-white">Rp {{ number_format($distributions->sum('total_shu'), 0, ',', '.') }}</td>
                        <td></td>
                    </tr>
                </tfoot>
                @endif
            </table>
        </div>
    </div>
</div>
@endsection
