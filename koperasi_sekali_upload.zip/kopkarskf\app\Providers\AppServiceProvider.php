<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Define Gates for authorization
        \Illuminate\Support\Facades\Gate::define('admin', function ($user) {
            return $user->hasAdminAccess();
        });
        
        \Illuminate\Support\Facades\Gate::define('member', function ($user) {
            return $user->isMember();
        });

        // Share settings to all views
        if (\Illuminate\Support\Facades\Schema::hasTable('settings')) {
            $globalSettings = \App\Models\Setting::all()->pluck('value', 'key');
            \Illuminate\Support\Facades\View::share('globalSettings', $globalSettings);
        }
    }
}
