<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\MembersImport;
use App\Imports\SavingsImport;
use App\Imports\LoansImport;
use App\Models\User;
use App\Models\Member;
use App\Models\Saving;
use App\Models\Loan;
use App\Models\LoanPayment;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class ImportController extends Controller
{
    /**
     * Show import page
     */
    public function index()
    {
        // Get counts for reset section
        $counts = [
            'members' => Member::count(),
            'users' => User::where('role', '!=', 'admin')->count(),
            'savings' => Saving::count(),
            'loans' => Loan::count(),
        ];

        return view('imports.index', compact('counts'));
    }

    /**
     * Import Members from Excel
     */
    public function importMembers(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv|max:2048'
        ]);

        try {
            $import = new MembersImport;
            Excel::import($import, $request->file('file'));
            
            // Check for validation failures
            $failures = $import->failures();
            if ($failures->isNotEmpty()) {
                $errorMessages = [];
                foreach ($failures as $failure) {
                    $row = $failure->row();
                    $attribute = $failure->attribute();
                    $errors = implode(', ', $failure->errors());
                    $errorMessages[] = "Baris {$row}: {$attribute} - {$errors}";
                }
                
                return redirect()->back()
                    ->with('error', 'Beberapa data gagal diimport:')
                    ->with('import_errors', $errorMessages);
            }
            
            return redirect()->back()->with('success', 'Data anggota berhasil diimport!');
        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            $failures = $e->failures();
            $errorMessages = [];
            foreach ($failures as $failure) {
                $row = $failure->row();
                $attribute = $failure->attribute();
                $errors = implode(', ', $failure->errors());
                $errorMessages[] = "Baris {$row}: {$attribute} - {$errors}";
            }
            
            return redirect()->back()
                ->with('error', 'Validasi gagal:')
                ->with('import_errors', $errorMessages);
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal import: ' . $e->getMessage());
        }
    }

    /**
     * Import Savings from Excel
     */
    public function importSavings(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv|max:2048'
        ]);

        try {
            Excel::import(new SavingsImport, $request->file('file'));
            
            return redirect()->back()->with('success', 'Data simpanan berhasil diimport!');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal import: ' . $e->getMessage());
        }
    }

    /**
     * Import Loans from Excel
     */
    public function importLoans(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv|max:2048'
        ]);

        try {
            Excel::import(new LoansImport, $request->file('file'));
            
            return redirect()->back()->with('success', 'Data pinjaman berhasil diimport!');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal import: ' . $e->getMessage());
        }
    }

    /**
     * Download example Excel templates
     */
    public function downloadTemplate($type)
    {
        $filename = match($type) {
            'members' => 'Template_Anggota.xlsx',
            'savings' => 'Template_Simpanan.xlsx',
            'loans' => 'Template_Pinjaman.xlsx',
            default => abort(404),
        };

        $export = match($type) {
            'members' => new \App\Exports\MembersTemplateExport(),
            'savings' => new \App\Exports\SavingsTemplateExport(),
            'loans' => new \App\Exports\LoansTemplateExport(),
        };

        return Excel::download($export, $filename);
    }

    /**
     * Reset/Delete all members (except admins)
     */
    public function resetMembers(Request $request)
    {
        $request->validate([
            'confirm' => 'required|in:HAPUS'
        ]);

        try {
            DB::beginTransaction();

            // Delete members first (this will cascade delete savings, loans due to foreign keys)
            Member::query()->delete();
            
            // Delete non-admin users
            User::where('role', '!=', 'admin')->delete();

            DB::commit();

            return redirect()->back()->with('success', 'Semua data anggota berhasil dihapus! (Admin tetap aman)');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Gagal reset: ' . $e->getMessage());
        }
    }

    /**
     * Reset/Delete all savings
     */
    public function resetSavings(Request $request)
    {
        $request->validate([
            'confirm' => 'required|in:HAPUS'
        ]);

        try {
            Saving::query()->delete();

            return redirect()->back()->with('success', 'Semua data simpanan berhasil dihapus!');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal reset: ' . $e->getMessage());
        }
    }

    /**
     * Reset/Delete all loans (and loan payments)
     */
    public function resetLoans(Request $request)
    {
        $request->validate([
            'confirm' => 'required|in:HAPUS'
        ]);

        try {
            DB::beginTransaction();

            // Delete loan payments first
            LoanPayment::query()->delete();
            
            // Then delete loans
            Loan::query()->delete();

            DB::commit();

            return redirect()->back()->with('success', 'Semua data pinjaman berhasil dihapus!');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Gagal reset: ' . $e->getMessage());
        }
    }

    /**
     * Reset ALL data (members, savings, loans) - DANGER!
     */
    public function resetAll(Request $request)
    {
        $request->validate([
            'confirm' => 'required|in:HAPUS SEMUA'
        ]);

        try {
            DB::beginTransaction();

            // Delete in order (respecting foreign keys)
            LoanPayment::query()->delete();
            Loan::query()->delete();
            Saving::query()->delete();
            Member::query()->delete();
            User::where('role', '!=', 'admin')->delete();

            DB::commit();

            return redirect()->back()->with('success', 'Semua data berhasil dihapus! Akun Admin tetap aman.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Gagal reset: ' . $e->getMessage());
        }
    }
}
