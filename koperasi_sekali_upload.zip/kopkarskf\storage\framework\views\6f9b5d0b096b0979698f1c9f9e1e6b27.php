<?php $__env->startSection('title', 'My Profile'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="page-header">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
                <h1 class="page-title"><?php echo e(__('Profile')); ?></h1>
                <p class="page-subtitle">Kelola informasi akun dan keamanan Anda</p>
            </div>
        </div>
    </div>

    <div class="space-y-6">
        <!-- Profile Information -->
        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('profile.partials.update-profile-information-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <!-- Points History -->
        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('profile.partials.points-history', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <!-- Update Password -->
        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <!-- Delete Account -->
        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('profile.partials.delete-user-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Koperasi\resources\views/profile/edit.blade.php ENDPATH**/ ?>