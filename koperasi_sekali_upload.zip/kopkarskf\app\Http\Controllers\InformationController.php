<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ShuSetting;
use App\Models\Setting;
use Barryvdh\DomPDF\Facade\Pdf;

class InformationController extends Controller
{
    public function adArt()
    {
        // Get latest SHU settings for percentage display
        $shuSetting = ShuSetting::orderBy('period_year', 'desc')->first();
        
        // Get cooperative settings as key-value array
        $settings = Setting::pluck('value', 'key')->toArray();
        
        return view('information.ad-art', compact('shuSetting', 'settings'));
    }

    public function downloadAdArtPdf()
    {
        // Get latest SHU settings for percentage display
        $shuSetting = ShuSetting::orderBy('period_year', 'desc')->first();
        
        // Get cooperative settings as key-value array
        $settings = Setting::pluck('value', 'key')->toArray();
        
        // Get coop name for filename
        $coopName = $settings['coop_name'] ?? 'Koperasi';
        $cleanName = preg_replace('/[^A-Za-z0-9]/', '_', $coopName);
        
        $pdf = Pdf::loadView('information.ad-art-pdf', compact('shuSetting', 'settings'))
            ->setPaper('a4', 'portrait');
        
        return $pdf->download("AD-ART_{$cleanName}.pdf");
    }

    public function governance()
    {
        return view('information.governance');
    }

    public function documentation()
    {
        return view('information.documentation');
    }

    public function uat()
    {
        return view('information.uat');
    }
}

