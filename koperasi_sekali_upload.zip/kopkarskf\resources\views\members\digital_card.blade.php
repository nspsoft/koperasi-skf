<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Anggota Digital - {{ $member->user->name }}</title>
    <!-- Tailwind via CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- QR Code Library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #111827; /* Dark bg for mobile focus */
        }
        
        .digital-card {
            background: linear-gradient(145deg, #1e3a8a 0%, #2563eb 100%);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.4), 0 10px 10px -5px rgba(0, 0, 0, 0.2);
        }

        .shine-effect {
            background: linear-gradient(120deg, rgba(255,255,255,0) 30%, rgba(255,255,255,0.1) 40%, rgba(255,255,255,0) 50%);
            background-size: 200% 100%;
            animation: shine 4s infinite linear;
        }

        @keyframes shine {
            0% { background-position: 100% 0; }
            100% { background-position: -100% 0; }
        }
    </style>
</head>
<body class="min-h-screen flex flex-col items-center justify-center p-4">

    <!-- Card Container -->
    <div class="w-full max-w-sm relative group perspective">
        <!-- The Card -->
        <div class="digital-card rounded-2xl overflow-hidden relative aspect-[9/16] flex flex-col shine-effect border border-white/10">
            
            <!-- Patterns -->
            <div class="absolute inset-0 opacity-20">
                <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="0.5"/>
                        </pattern>
                    </defs>
                    <rect width="100%" height="100%" fill="url(#grid)" />
                </svg>
            </div>

            <!-- Header -->
            <div class="relative z-10 px-6 pt-8 pb-4">
                <div class="flex items-center justify-between">
                    <div class="bg-white/10 backdrop-blur-md border border-white/20 p-2 rounded-lg overflow-hidden w-12 h-12 flex items-center justify-center">
                        @php
                            $logo = \App\Models\Setting::get('coop_logo');
                            $coopName = \App\Models\Setting::get('coop_name', 'SPINDO KARAWANG FACTORY');
                        @endphp
                        
                        @if($logo)
                             <img src="{{ Storage::url($logo) }}" class="w-full h-full object-contain">
                        @else
                            <svg class="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 2L1 21h22L12 2zm0 4l7.53 13H4.47L12 6z"/>
                            </svg>
                        @endif
                    </div>
                    <div class="text-right">
                         <h2 class="text-lg font-bold text-white tracking-wider max-w-[200px] leading-tight">{{ $coopName }}</h2>
                         <p class="text-[10px] text-blue-200 uppercase tracking-[0.2em]">Member Access</p>
                    </div>
                </div>
            </div>

            <!-- Photo -->
            <div class="relative z-10 px-6 mb-4 flex justify-center">
                <div class="relative w-32 h-32">
                    <div class="absolute inset-0 bg-blue-400 rounded-full blur-xl opacity-30 animate-pulse"></div>
                    @if($member->photo && Storage::disk('public')->exists($member->photo))
                        <img src="{{ Storage::url($member->photo) }}" class="w-full h-full rounded-full object-cover border-4 border-white/20 relative z-10 shadow-xl">
                    @else
                        {{-- Gender-based Avatar --}}
                        <div class="w-full h-full rounded-full bg-gradient-to-br {{ $member->gender === 'female' ? 'from-pink-400 to-rose-500' : 'from-cyan-400 to-blue-500' }} flex items-center justify-center border-4 border-white/20 relative z-10 shadow-xl overflow-hidden">
                            @if($member->gender === 'female')
                                {{-- Female Avatar - Woman silhouette --}}
                                <svg class="w-20 h-20 text-white" viewBox="0 0 24 24" fill="currentColor">
                                    <circle cx="12" cy="8" r="4"/>
                                    <path d="M12 14c-6.1 0-8 4-8 4v2h16v-2s-1.9-4-8-4z"/>
                                </svg>
                            @else
                                {{-- Male Avatar - Man silhouette --}}
                                <svg class="w-20 h-20 text-white" viewBox="0 0 24 24" fill="currentColor">
                                    <circle cx="12" cy="7" r="4"/>
                                    <path d="M12 13c-5 0-8 3-8 5v2h16v-2c0-2-3-5-8-5z"/>
                                </svg>
                            @endif
                        </div>
                    @endif
                    <div class="absolute bottom-2 right-0 z-20">
                        <span class="bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full border-2 border-[#1e3a8a] shadow-sm">
                            {{ $member->status == 'active' ? 'AKTIF' : 'NON-AKTIF' }}
                        </span>
                    </div>
                </div>
            </div>

            <!-- Identity -->
            <div class="relative z-10 px-6 text-center space-y-1 mb-6">
                <h1 class="text-2xl font-bold text-white">{{ $member->user->name }}</h1>
                <p class="text-blue-200 text-sm font-medium">{{ $member->position ?? 'Anggota Koperasi' }}</p>
                <p class="text-blue-300/80 text-xs">{{ $member->department ?? '-' }}</p>
            </div>

            <!-- Info Grid -->
            <div class="relative z-10 px-6 grid grid-cols-2 gap-4 text-xs mb-8">
                <div class="bg-black/20 rounded-lg p-3 backdrop-blur-sm">
                    <p class="text-blue-300 mb-1">ID Anggota</p>
                    <p class="text-white font-mono font-bold tracking-wide">{{ $member->member_id }}</p>
                </div>
                <div class="bg-black/20 rounded-lg p-3 backdrop-blur-sm">
                    <p class="text-blue-300 mb-1">Bergabung</p>
                    <p class="text-white font-medium">{{ $member->join_date->format('d M Y') }}</p>
                </div>
            </div>

            <!-- QR Code Area -->
            <div class="mt-auto relative z-10 bg-white p-6 rounded-t-3xl flex flex-col items-center justify-center">
                 <p class="text-xs text-center text-gray-500 mb-4 font-medium uppercase tracking-wider">Scan untuk verifikasi</p>
                 <div id="qrcode" class="mb-2"></div>
                 <p class="text-[10px] text-gray-400 mt-2">{{ $member->user->email }}</p>
            </div>
            
        </div>
        
        <!-- Action Buttons (Outside Card) -->
        <div class="mt-8 flex gap-3 justify-center">
             <button onclick="window.close()" class="text-gray-400 hover:text-white transition px-4 py-2">
                Tutup
            </button>
            <button onclick="downloadCard()" class="bg-white text-blue-900 hover:bg-blue-50 px-6 py-2 rounded-full font-bold shadow-lg transition transform hover:-translate-y-1 flex items-center gap-2">
                 <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                Download
            </button>
        </div>
    </div>

    <!-- html2canvas for Download -->
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>

    <script>
        // Generate QR Code
        new QRCode(document.getElementById("qrcode"), {
            text: "{{ $member->member_id }}",
            width: 120,
            height: 120,
            colorDark : "#111827",
            colorLight : "#ffffff",
            correctLevel : QRCode.CorrectLevel.H
        });

        // Download Function
        function downloadCard() {
            const card = document.querySelector('.digital-card');
            
            html2canvas(card, {
                scale: 2, // High res
                backgroundColor: null,
                useCORS: true
            }).then(canvas => {
                const link = document.createElement('a');
                link.download = 'MemberCard-{{ $member->member_id }}.png';
                link.href = canvas.toDataURL('image/png');
                link.click();
            });
        }
    </script>
</body>
</html>
