<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Product::with('category');
        
        if ($request->search) {
            $query->where('name', 'like', '%'.$request->search.'%')
                  ->orWhere('code', 'like', '%'.$request->search.'%');
        }

        $products = $query->latest()->paginate(10);
        return view('commerce.products.index', compact('products'));
    }

    /**
     * Export products data to Excel based on search filter.
     */
    public function export(Request $request)
    {
        if (!auth()->user()->hasAdminAccess()) {
            abort(403);
        }

        $query = Product::with('category');
        
        if ($request->search) {
            $query->where('name', 'like', '%'.$request->search.'%')
                  ->orWhere('code', 'like', '%'.$request->search.'%');
        }

        $products = $query->latest()->get();

        // Create Excel file
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Data Produk');

        // Style Settings
        $titleStyle = [
            'font' => ['bold' => true, 'size' => 16],
            'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
        ];
        $headerStyle = [
            'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
            'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['rgb' => '4F46E5']],
            'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
            'borders' => ['allBorders' => ['borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN]],
        ];
        $subtitleStyle = [
            'font' => ['italic' => true, 'size' => 10, 'color' => ['rgb' => '666666']],
            'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
        ];

        // Report Title
        $sheet->mergeCells('A1:I1');
        $sheet->setCellValue('A1', 'LAPORAN DATA PRODUK / STOK');
        $sheet->getStyle('A1')->applyFromArray($titleStyle);

        // Filter Info
        $filterInfo = [];
        if ($request->search) $filterInfo[] = "Pencarian: \"{$request->search}\"";
        
        $sheet->mergeCells('A2:I2');
        $sheet->setCellValue('A2', empty($filterInfo) ? 'Semua Data - Diunduh: ' . date('d/m/Y H:i') : implode(' | ', $filterInfo) . ' | Diunduh: ' . date('d/m/Y H:i'));
        $sheet->getStyle('A2')->applyFromArray($subtitleStyle);

        // Empty row
        $sheet->setCellValue('A3', '');

        // Column Headers (at row 4)
        $headers = ['No', 'Kode Produk', 'Nama Produk', 'Kategori', 'Stok', 'Harga Modal', 'Harga Jual', 'Status', 'Deskripsi'];
        $col = 'A';
        foreach ($headers as $header) {
            $sheet->setCellValue($col . '4', $header);
            $col++;
        }
        $sheet->getStyle('A4:I4')->applyFromArray($headerStyle);

        // Data (starting at row 5)
        $row = 5;
        foreach ($products as $index => $product) {
            $sheet->setCellValue('A' . $row, $index + 1);
            $sheet->setCellValue('B' . $row, $product->code);
            $sheet->setCellValue('C' . $row, $product->name);
            $sheet->setCellValue('D' . $row, $product->category->name ?? '-');
            $sheet->setCellValue('E' . $row, $product->stock);
            $sheet->setCellValue('F' . $row, $product->cost);
            $sheet->setCellValue('G' . $row, $product->price);
            $sheet->setCellValue('H' . $row, $product->is_active ? 'Aktif' : 'Non-aktif');
            $sheet->setCellValue('I' . $row, $product->description ?? '-');
            $row++;
        }

        // Format amount columns
        $sheet->getStyle('F5:G' . ($row - 1))->getNumberFormat()->setFormatCode('#,##0');

        // Auto-size columns
        foreach (range('A', 'I') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }

        // Add borders to data
        $sheet->getStyle('A4:I' . ($row - 1))->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

        // Download
        $filename = 'Data_Produk_' . date('Y-m-d_His') . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        
        $writer->save('php://output');
        exit;
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::all();
        return view('commerce.products.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'code' => 'required|string|unique:products',
            'name' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'cost' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'image' => 'nullable|image|max:2048',
            'is_preorder' => 'nullable|boolean',
            'preorder_eta' => 'nullable|string|max:255',
        ]);

        $data = $request->all();

        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('products', 'public');
        }

        Product::create($data);

        return redirect()->route('products.index')->with('success', 'Produk berhasil ditambahkan');
    }

    /**
     * Display the specified resource.
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Product $product)
    {
        $categories = Category::all();
        return view('commerce.products.edit', compact('product', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Product $product)
    {
        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'code' => 'required|string|unique:products,code,'.$product->id,
            'name' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'cost' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'image' => 'nullable|image|max:2048',
            'is_preorder' => 'nullable|boolean',
            'preorder_eta' => 'nullable|string|max:255',
        ]);

        $data = $request->all();

        if ($request->hasFile('image')) {
            // Delete old image if exists
            if ($product->image) {
                \Storage::disk('public')->delete($product->image);
            }
            $data['image'] = $request->file('image')->store('products', 'public');
        }

        $product->update($data);

        return redirect()->route('products.index')->with('success', 'Produk berhasil diperbarui');
    }

    /**
     * Update product image only (AJAX)
     */
    public function updateImage(Request $request, Product $product)
    {
        $request->validate([
            'image' => 'required|image|max:2048',
        ]);

        if ($request->hasFile('image')) {
            // Delete old image if exists
            if ($product->image) {
                Storage::disk('public')->delete($product->image);
            }
            
            $path = $request->file('image')->store('products', 'public');
            $product->update(['image' => $path]);

            return response()->json([
                'success' => true,
                'image_url' => Storage::url($path),
                'message' => 'Gambar berhasil diperbarui'
            ]);
        }

        return response()->json(['success' => false, 'message' => 'Tidak ada gambar yang diupload'], 400);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Product $product)
    {
        if ($product->image) {
            \Storage::disk('public')->delete($product->image);
        }
        
        $product->delete();
        return redirect()->route('products.index')->with('success', 'Produk berhasil dihapus');
    }

    /**
     * Show bulk upload form
     */
    public function bulkUpload()
    {
        return view('commerce.products.bulk-upload');
    }

    /**
     * Download Excel template for bulk upload
     */
    public function downloadTemplate()
    {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Template Produk');

        // Headers with styling
        $headers = ['Kode Produk*', 'Nama Produk*', 'Kategori', 'Harga Jual', 'Harga Modal', 'Stok', 'Nama File Gambar', 'Deskripsi'];
        $sheet->fromArray($headers, null, 'A1');
        
        // Style headers
        $headerStyle = [
            'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
            'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['rgb' => '4F46E5']],
            'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
        ];
        $sheet->getStyle('A1:H1')->applyFromArray($headerStyle);
        
        // Sample data
        $sampleData = [
            ['PRD001', 'Beras Premium 5kg', 'Sembako', 65000, 60000, 50, 'PRD001.jpg', 'Beras premium kualitas terbaik'],
            ['PRD002', 'Minyak Goreng 2L', 'Sembako', 32000, 28000, 100, 'PRD002.jpg', 'Minyak goreng jernih'],
            ['PRD003', 'Indomie Goreng', 'Sembako', 3500, 3000, 200, '', 'Mie instan rasa goreng'],
            ['PRD004', 'Gula Pasir 1kg', 'Sembako', 15000, 13000, 80, '', ''],
            ['PRD005', 'Teh Celup Kotak', 'Minuman', 8500, 7000, 60, '', 'Teh celup 25 sachet'],
        ];
        $sheet->fromArray($sampleData, null, 'A2');
        
        // Auto-size columns
        foreach (range('A', 'H') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }
        
        // Add instruction sheet
        $instructionSheet = $spreadsheet->createSheet();
        $instructionSheet->setTitle('Petunjuk');
        $instructions = [
            ['PETUNJUK PENGISIAN TEMPLATE PRODUK'],
            [''],
            ['Kolom dengan tanda * adalah WAJIB diisi'],
            [''],
            ['Kode Produk* - Kode unik untuk setiap produk (contoh: PRD001, SKU-123)'],
            ['Nama Produk* - Nama lengkap produk'],
            ['Kategori - Nama kategori (akan dibuat otomatis jika belum ada)'],
            ['Harga Jual - Harga jual ke pelanggan (angka tanpa titik/koma)'],
            ['Harga Modal - Harga beli/modal (angka tanpa titik/koma)'],
            ['Stok - Jumlah stok awal'],
            ['Nama File Gambar - Nama file gambar (opsional, upload terpisah)'],
            ['Deskripsi - Deskripsi produk (opsional)'],
            [''],
            ['TIPS:'],
            ['- Hapus baris contoh sebelum mengisi data Anda'],
            ['- Untuk upload gambar, gunakan fitur Bulk Upload Gambar'],
            ['- Nama file gambar harus sama dengan Kode Produk'],
        ];
        $instructionSheet->fromArray($instructions, null, 'A1');
        $instructionSheet->getStyle('A1')->getFont()->setBold(true)->setSize(14);
        $instructionSheet->getColumnDimension('A')->setWidth(60);
        
        // Set first sheet as active
        $spreadsheet->setActiveSheetIndex(0);
        
        // Generate file
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $filename = 'template_produk.xlsx';
        
        return response()->streamDownload(function() use ($writer) {
            $writer->save('php://output');
        }, $filename, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ]);
    }

    /**
     * Import products from Excel/CSV file
     */
    public function importExcel(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:csv,xlsx,xls|max:5120',
        ]);

        $updateExisting = $request->has('update_existing');
        $result = ['success' => 0, 'updated' => 0, 'failed' => 0, 'errors' => []];

        try {
            $file = $request->file('file');
            $extension = strtolower($file->getClientOriginalExtension());
            
            if ($extension === 'csv') {
                $data = $this->parseCsv($file);
            } else {
                // Parse Excel file using PhpSpreadsheet
                $data = $this->parseExcel($file);
            }

            foreach ($data as $index => $row) {
                try {
                    if (empty($row['code']) || empty($row['name'])) {
                        $result['errors'][] = "Baris " . ($index + 2) . ": Kode dan nama produk wajib diisi";
                        $result['failed']++;
                        continue;
                    }

                    // Find or create category
                    $category = Category::firstOrCreate(
                        ['name' => $row['category'] ?? 'Umum'],
                        ['name' => $row['category'] ?? 'Umum']
                    );

                    $existingProduct = Product::where('code', $row['code'])->first();

                    if ($existingProduct) {
                        if ($updateExisting) {
                            $existingProduct->update([
                                'name' => $row['name'],
                                'category_id' => $category->id,
                                'price' => $row['price'] ?? 0,
                                'cost' => $row['cost'] ?? 0,
                                'stock' => $row['stock'] ?? 0,
                                'description' => $row['description'] ?? null,
                            ]);
                            $result['updated']++;
                        } else {
                            $result['errors'][] = "Baris " . ($index + 2) . ": Kode {$row['code']} sudah ada";
                            $result['failed']++;
                        }
                    } else {
                        Product::create([
                            'code' => $row['code'],
                            'name' => $row['name'],
                            'category_id' => $category->id,
                            'price' => $row['price'] ?? 0,
                            'cost' => $row['cost'] ?? 0,
                            'stock' => $row['stock'] ?? 0,
                            'description' => $row['description'] ?? null,
                            'is_active' => true,
                        ]);
                        $result['success']++;
                    }
                } catch (\Exception $e) {
                    $result['errors'][] = "Baris " . ($index + 2) . ": " . $e->getMessage();
                    $result['failed']++;
                }
            }

        } catch (\Exception $e) {
            return back()->with('error', 'Gagal membaca file: ' . $e->getMessage());
        }

        return back()->with('import_result', $result)->with('success', 'Import selesai!');
    }

    /**
     * Parse CSV file
     */
    protected function parseCsv($file)
    {
        $data = [];
        $handle = fopen($file->getPathname(), 'r');
        
        // Skip BOM if present
        $bom = fread($handle, 3);
        if ($bom !== chr(0xEF).chr(0xBB).chr(0xBF)) {
            rewind($handle);
        }
        
        $headers = fgetcsv($handle);
        $headers = array_map('trim', $headers);
        $headers = array_map('strtolower', $headers);
        // Normalize header names
        $headers = $this->normalizeHeaders($headers);
        
        while (($row = fgetcsv($handle)) !== false) {
            if (count($row) === count($headers)) {
                $data[] = array_combine($headers, $row);
            }
        }
        
        fclose($handle);
        return $data;
    }

    /**
     * Parse Excel file using PhpSpreadsheet
     */
    protected function parseExcel($file)
    {
        $data = [];
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($file->getPathname());
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();
        
        if (count($rows) < 2) {
            return $data;
        }
        
        // First row is headers
        $headers = array_map('trim', $rows[0]);
        $headers = array_map('strtolower', $headers);
        // Normalize header names
        $headers = $this->normalizeHeaders($headers);
        
        // Process data rows (skip header)
        for ($i = 1; $i < count($rows); $i++) {
            $row = $rows[$i];
            
            // Skip empty rows
            if (empty(array_filter($row))) {
                continue;
            }
            
            if (count($row) >= count($headers)) {
                $rowData = [];
                foreach ($headers as $index => $header) {
                    $rowData[$header] = $row[$index] ?? '';
                }
                $data[] = $rowData;
            }
        }
        
        return $data;
    }

    /**
     * Normalize header names to match expected format
     */
    protected function normalizeHeaders($headers)
    {
        $mapping = [
            'kode produk*' => 'code',
            'kode produk' => 'code',
            'kode' => 'code',
            'code' => 'code',
            'nama produk*' => 'name',
            'nama produk' => 'name',
            'nama' => 'name',
            'name' => 'name',
            'kategori' => 'category',
            'category' => 'category',
            'harga jual' => 'price',
            'harga' => 'price',
            'price' => 'price',
            'harga modal' => 'cost',
            'modal' => 'cost',
            'cost' => 'cost',
            'stok' => 'stock',
            'stock' => 'stock',
            'nama file gambar' => 'image_file',
            'gambar' => 'image_file',
            'image' => 'image_file',
            'image_file' => 'image_file',
            'deskripsi' => 'description',
            'description' => 'description',
        ];
        
        return array_map(function($header) use ($mapping) {
            $normalized = strtolower(trim($header));
            return $mapping[$normalized] ?? $normalized;
        }, $headers);
    }

    /**
     * Bulk upload images - match by product code
     */
    public function bulkImages(Request $request)
    {
        $request->validate([
            'images.*' => 'required|image|max:2048',
        ]);

        $matched = 0;
        $notFound = [];

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                // Get filename without extension as product code
                $filename = pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME);
                
                // Find product by code
                $product = Product::where('code', $filename)->first();
                
                if ($product) {
                    // Delete old image if exists
                    if ($product->image) {
                        Storage::disk('public')->delete($product->image);
                    }
                    
                    // Store new image
                    $path = $image->store('products', 'public');
                    $product->update(['image' => $path]);
                    $matched++;
                } else {
                    $notFound[] = $image->getClientOriginalName();
                }
            }
        }

        $message = "Berhasil upload {$matched} gambar.";
        if (count($notFound) > 0) {
            $message .= " " . count($notFound) . " file tidak ditemukan produknya: " . implode(', ', array_slice($notFound, 0, 5));
            if (count($notFound) > 5) {
                $message .= "...";
            }
        }

        return back()->with('success', $message);
    }
}
