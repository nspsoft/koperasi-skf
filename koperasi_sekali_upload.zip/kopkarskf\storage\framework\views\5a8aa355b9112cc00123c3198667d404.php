

<?php $__env->startSection('title', 'Kalkulator SHU'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto space-y-6">
    <!-- Header -->
    <div class="flex items-center gap-4">
        <a href="<?php echo e(route('shu.index')); ?>" class="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
            <svg class="w-6 h-6 text-gray-600 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
            </svg>
        </a>
        <div>
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Kalkulator SHU</h1>
            <p class="text-gray-600 dark:text-gray-400 mt-1">Konfigurasi & hitung Sisa Hasil Usaha sesuai UU Perkoperasian.</p>
        </div>
    </div>

    <!-- Regulatory Info Box -->
    <div class="bg-blue-50 dark:bg-blue-900/30 border border-blue-100 dark:border-blue-800 rounded-xl p-4">
        <div class="flex gap-3">
            <svg class="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <div class="text-sm text-blue-800 dark:text-blue-300">
                <p class="font-semibold mb-1">Dasar Hukum: UU No. 25 Tahun 1992 Pasal 45</p>
                <ul class="list-disc list-inside space-y-0.5 text-xs">
                    <li><strong>Dana Cadangan:</strong> Minimal 20% (untuk pengembangan usaha)</li>
                    <li><strong>Jasa Modal:</strong> Untuk anggota berdasarkan simpanan</li>
                    <li><strong>Jasa Usaha:</strong> Untuk anggota berdasarkan transaksi/partisipasi</li>
                    <li><strong>Dana Lainnya:</strong> Pengurus, karyawan, pendidikan, sosial, pembangunan</li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="glass-card-solid p-6">
        <form action="<?php echo e(route('shu.save-settings')); ?>" method="POST" class="space-y-6" id="shuForm">
            <?php echo csrf_field(); ?>

            <!-- Year & Total Pool -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="form-label">Tahun Periode <span class="text-red-500">*</span></label>
                    <select name="year" class="form-input" required onchange="window.location.href='<?php echo e(route('shu.calculator')); ?>?year='+this.value">
                        <?php $__currentLoopData = $availableYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($y); ?>" <?php echo e($year == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="form-label">Total SHU (Laba Bersih) <span class="text-red-500">*</span></label>
                    <div class="relative">
                        <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">Rp</span>
                        <input type="number" name="total_shu_pool" value="<?php echo e(old('total_shu_pool', $setting->total_shu_pool ?? 0)); ?>" 
                               class="form-input pl-10" placeholder="0" min="0" step="1000" required id="totalPool">
                    </div>
                    <p class="text-xs text-gray-500 mt-1">Total laba bersih tahun buku yang akan dibagikan</p>
                </div>
            </div>

            <!-- Allocation Percentages -->
            <div class="border-t border-gray-100 dark:border-gray-700 pt-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300">Pembagian Persentase SHU</h3>
                    <div class="text-sm font-bold" id="totalPersenDisplay">
                        Total: <span id="totalPersen" class="text-primary-600">0</span>%
                    </div>
                </div>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <!-- Dana Cadangan -->
                    <div class="bg-red-50 dark:bg-red-900/20 p-3 rounded-lg">
                        <label class="text-xs font-medium text-red-700 dark:text-red-400 uppercase">Dana Cadangan</label>
                        <div class="relative mt-1">
                            <input type="number" name="persen_cadangan" value="<?php echo e(old('persen_cadangan', $setting->persen_cadangan ?? 25)); ?>" 
                                   class="form-input pr-8 text-sm persen-input" min="20" max="100" step="0.5" required>
                            <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">%</span>
                        </div>
                        <p class="text-[10px] text-red-600 dark:text-red-400 mt-1">Min 20% (UU)</p>
                    </div>

                    <!-- Jasa Modal (Anggota) -->
                    <div class="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
                        <label class="text-xs font-medium text-green-700 dark:text-green-400 uppercase">Jasa Modal</label>
                        <div class="relative mt-1">
                            <input type="number" name="persen_jasa_modal" value="<?php echo e(old('persen_jasa_modal', $setting->persen_jasa_modal ?? 30)); ?>" 
                                   class="form-input pr-8 text-sm persen-input" min="0" max="100" step="0.5" required>
                            <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">%</span>
                        </div>
                        <p class="text-[10px] text-green-600 dark:text-green-400 mt-1">Berdasarkan simpanan anggota</p>
                    </div>

                    <!-- Jasa Usaha (Anggota) -->
                    <div class="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                        <label class="text-xs font-medium text-blue-700 dark:text-blue-400 uppercase">Jasa Usaha</label>
                        <div class="relative mt-1">
                            <input type="number" name="persen_jasa_usaha" value="<?php echo e(old('persen_jasa_usaha', $setting->persen_jasa_usaha ?? 25)); ?>" 
                                   class="form-input pr-8 text-sm persen-input" min="0" max="100" step="0.5" required>
                            <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">%</span>
                        </div>
                        <p class="text-[10px] text-blue-600 dark:text-blue-400 mt-1">Berdasarkan transaksi anggota</p>
                    </div>

                    <!-- Dana Pengurus -->
                    <div class="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg">
                        <label class="text-xs font-medium text-purple-700 dark:text-purple-400 uppercase">Dana Pengurus</label>
                        <div class="relative mt-1">
                            <input type="number" name="persen_pengurus" value="<?php echo e(old('persen_pengurus', $setting->persen_pengurus ?? 5)); ?>" 
                                   class="form-input pr-8 text-sm persen-input" min="0" max="100" step="0.5" required>
                            <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">%</span>
                        </div>
                    </div>

                    <!-- Dana Karyawan -->
                    <div class="bg-amber-50 dark:bg-amber-900/20 p-3 rounded-lg">
                        <label class="text-xs font-medium text-amber-700 dark:text-amber-400 uppercase">Dana Karyawan</label>
                        <div class="relative mt-1">
                            <input type="number" name="persen_karyawan" value="<?php echo e(old('persen_karyawan', $setting->persen_karyawan ?? 5)); ?>" 
                                   class="form-input pr-8 text-sm persen-input" min="0" max="100" step="0.5" required>
                            <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">%</span>
                        </div>
                    </div>

                    <!-- Dana Pendidikan -->
                    <div class="bg-indigo-50 dark:bg-indigo-900/20 p-3 rounded-lg">
                        <label class="text-xs font-medium text-indigo-700 dark:text-indigo-400 uppercase">Dana Pendidikan</label>
                        <div class="relative mt-1">
                            <input type="number" name="persen_pendidikan" value="<?php echo e(old('persen_pendidikan', $setting->persen_pendidikan ?? 5)); ?>" 
                                   class="form-input pr-8 text-sm persen-input" min="0" max="100" step="0.5" required>
                            <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">%</span>
                        </div>
                    </div>

                    <!-- Dana Sosial -->
                    <div class="bg-pink-50 dark:bg-pink-900/20 p-3 rounded-lg">
                        <label class="text-xs font-medium text-pink-700 dark:text-pink-400 uppercase">Dana Sosial</label>
                        <div class="relative mt-1">
                            <input type="number" name="persen_sosial" value="<?php echo e(old('persen_sosial', $setting->persen_sosial ?? 2.5)); ?>" 
                                   class="form-input pr-8 text-sm persen-input" min="0" max="100" step="0.5" required>
                            <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">%</span>
                        </div>
                    </div>

                    <!-- Dana Pembangunan -->
                    <div class="bg-teal-50 dark:bg-teal-900/20 p-3 rounded-lg">
                        <label class="text-xs font-medium text-teal-700 dark:text-teal-400 uppercase">Dana Pembangunan</label>
                        <div class="relative mt-1">
                            <input type="number" name="persen_pembangunan" value="<?php echo e(old('persen_pembangunan', $setting->persen_pembangunan ?? 2.5)); ?>" 
                                   class="form-input pr-8 text-sm persen-input" min="0" max="100" step="0.5" required>
                            <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">%</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Preview Breakdown -->
            <?php if($setting && $setting->exists && $setting->total_shu_pool > 0): ?>
            <div class="border-t border-gray-100 dark:border-gray-700 pt-6">
                <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-4">Pratinjau Pembagian</h3>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                    <div class="bg-gray-50 dark:bg-gray-700/50 p-3 rounded-lg">
                        <p class="text-xs text-gray-500">Dana Cadangan</p>
                        <p class="font-bold text-gray-900 dark:text-white">Rp <?php echo e(number_format($setting->pool_cadangan, 0, ',', '.')); ?></p>
                    </div>
                    <div class="bg-green-50 dark:bg-green-900/30 p-3 rounded-lg">
                        <p class="text-xs text-green-600">Jasa Modal (Anggota)</p>
                        <p class="font-bold text-green-700 dark:text-green-400">Rp <?php echo e(number_format($setting->pool_jasa_modal, 0, ',', '.')); ?></p>
                    </div>
                    <div class="bg-blue-50 dark:bg-blue-900/30 p-3 rounded-lg">
                        <p class="text-xs text-blue-600">Jasa Usaha (Anggota)</p>
                        <p class="font-bold text-blue-700 dark:text-blue-400">Rp <?php echo e(number_format($setting->pool_jasa_usaha, 0, ',', '.')); ?></p>
                    </div>
                    <div class="bg-primary-50 dark:bg-primary-900/30 p-3 rounded-lg">
                        <p class="text-xs text-primary-600">Total Untuk Anggota</p>
                        <p class="font-bold text-primary-700 dark:text-primary-400">Rp <?php echo e(number_format($setting->pool_anggota, 0, ',', '.')); ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Actions -->
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                <div class="text-sm text-gray-500">
                    <?php if($setting && $setting->exists): ?>
                    Status: <span class="badge badge-<?php echo e($setting->status_color); ?>"><?php echo e($setting->status_label); ?></span>
                    <?php endif; ?>
                </div>
                <div class="flex gap-3">
                    <a href="<?php echo e(route('shu.index')); ?>" class="btn-secondary">Batal</a>
                    <button type="submit" class="btn-primary">
                        Simpan Konfigurasi
                    </button>
                    <?php if($setting && $setting->exists && $setting->total_shu_pool > 0): ?>
                    <button type="button" onclick="document.getElementById('calculateForm').submit();" class="btn-success">
                        Hitung SHU Anggota
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </form>

        <?php if($setting && $setting->exists): ?>
        <form id="calculateForm" action="<?php echo e(route('shu.calculate')); ?>" method="POST" class="hidden">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="year" value="<?php echo e($year); ?>">
        </form>
        <?php endif; ?>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const inputs = document.querySelectorAll('.persen-input');
        const totalDisplay = document.getElementById('totalPersen');
        const totalContainer = document.getElementById('totalPersenDisplay');

        function updateTotal() {
            let total = 0;
            inputs.forEach(input => {
                total += parseFloat(input.value) || 0;
            });
            totalDisplay.textContent = total.toFixed(1);
            
            if (Math.abs(total - 100) < 0.1) {
                totalContainer.classList.remove('text-red-600');
                totalContainer.classList.add('text-green-600');
            } else {
                totalContainer.classList.remove('text-green-600');
                totalContainer.classList.add('text-red-600');
            }
        }

        inputs.forEach(input => {
            input.addEventListener('input', updateTotal);
        });

        updateTotal();
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Koperasi\resources\views/shu/calculator.blade.php ENDPATH**/ ?>