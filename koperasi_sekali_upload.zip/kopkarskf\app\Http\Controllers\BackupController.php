<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BackupController extends Controller
{
    /**
     * Show backup management page
     */
    public function index()
    {
        $backups = $this->getExistingBackups();
        return view('settings.backup', compact('backups'));
    }

    /**
     * Download database backup
     */
    public function download()
    {
        $database = config('database.connections.mysql.database');
        $username = config('database.connections.mysql.username');
        $password = config('database.connections.mysql.password');
        $host = config('database.connections.mysql.host');

        $filename = 'backup_' . $database . '_' . date('Y-m-d_H-i-s') . '.sql';
        $path = storage_path('app/backups/' . $filename);

        // Ensure backup directory exists
        if (!file_exists(storage_path('app/backups'))) {
            mkdir(storage_path('app/backups'), 0755, true);
        }

        // Build mysqldump command
        $command = "mysqldump --user={$username} --password=\"{$password}\" --host={$host} {$database} > \"{$path}\"";
        
        // Execute command
        exec($command, $output, $returnVar);

        if ($returnVar !== 0) {
            return redirect()->back()->with('error', 'Gagal membuat backup database. Pastikan mysqldump tersedia.');
        }

        // Return file download
        return response()->download($path, $filename, [
            'Content-Type' => 'application/sql',
        ])->deleteFileAfterSend(false);
    }

    /**
     * Restore database from uploaded file
     */
    public function restore(Request $request)
    {
        $request->validate([
            'backup_file' => 'required|file|max:51200', // max 50MB
        ]);

        // Store uploaded file temporarily - use getRealPath directly from uploaded file
        $file = $request->file('backup_file');
        $fullPath = $file->getRealPath();

        try {
            // Read SQL file content
            $sql = file_get_contents($fullPath);
            
            if (empty($sql)) {
                throw new \Exception('File backup kosong.');
            }

            // Disable foreign key checks
            \DB::statement('SET FOREIGN_KEY_CHECKS=0');
            
            // Split SQL into individual statements
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            
            foreach ($statements as $statement) {
                if (!empty($statement)) {
                    try {
                        \DB::unprepared($statement);
                    } catch (\Exception $e) {
                        // Skip errors for DROP/CREATE statements
                        continue;
                    }
                }
            }
            
            // Re-enable foreign key checks
            \DB::statement('SET FOREIGN_KEY_CHECKS=1');
            
            return redirect()->back()->with('success', 'Database berhasil direstore!');
            
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal restore database: ' . $e->getMessage());
        }
    }

    /**
     * Delete a backup file
     */
    public function destroy($filename)
    {
        $path = storage_path('app/backups/' . $filename);
        
        if (file_exists($path)) {
            unlink($path);
            return redirect()->back()->with('success', 'Backup berhasil dihapus.');
        }

        return redirect()->back()->with('error', 'File backup tidak ditemukan.');
    }

    /**
     * Get list of existing backups
     */
    private function getExistingBackups()
    {
        $backupPath = storage_path('app/backups');
        
        if (!file_exists($backupPath)) {
            return collect([]);
        }

        $files = scandir($backupPath);
        $backups = collect([]);

        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            if (pathinfo($file, PATHINFO_EXTENSION) !== 'sql') continue;

            $fullPath = $backupPath . '/' . $file;
            $backups->push([
                'name' => $file,
                'size' => filesize($fullPath),
                'date' => filemtime($fullPath),
            ]);
        }

        return $backups->sortByDesc('date')->values();
    }
}
