<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo e($title); ?></title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 10pt;
            line-height: 1.4;
            color: #333;
            margin: 0.5cm;
        }
        .header-table {
            width: 100%;
            border-bottom: 2px solid #000;
            margin-bottom: 20px;
            padding-bottom: 10px;
        }
        .logo-cell {
            width: 90px;
            text-align: center;
            vertical-align: middle;
        }
        .header-text {
            text-align: center;
            vertical-align: middle;
            padding: 0 10px;
        }
        .header-text h1 {
            font-size: 14pt;
            margin: 0;
            padding: 0;
            line-height: 1.1;
            text-transform: uppercase;
        }
        .header-text h2 {
            font-size: 12pt;
            margin: 2px 0;
            padding: 0;
            line-height: 1.1;
            text-transform: uppercase;
        }
        .header-text p {
            font-size: 8pt;
            margin: 2px 0 0 0;
            line-height: 1.2;
            font-style: italic;
        }
        .content {
            margin-top: 20px;
        }
        table {
            border-collapse: collapse;
        }
        @page {
            margin: 1.5cm 2cm;
        }
    </style>
</head>
<body>
    <table class="header-table">
        <tr>
            <td class="logo-cell">
                <?php if($logo1): ?>
                    <img src="<?php echo e($logo1); ?>" style="max-height: 85px; width: auto;">
                <?php else: ?>
                    <div style="width: 80px; height: 80px; border: 1px dashed #ccc; line-height: 80px; font-size: 8pt; color: #999;">LOGO 1</div>
                <?php endif; ?>
            </td>
            <td class="header-text">
                <h1>KOPERASI KARYAWAN</h1>
                <h1>SPINDO KARAWANG FACTORY</h1>
                <h2>PT Steel Pipe Industry Of Indonesia Tbk</h2>
                <p>Jl. Mitra Raya Blok F2 Kawasan Industri Mitra Karawang, Ds. Parungmulya Kec. Ciampel Karawang</p>
            </td>
            <td class="logo-cell">
                <?php if($logo2): ?>
                    <img src="<?php echo e($logo2); ?>" style="max-height: 85px; width: auto;">
                <?php else: ?>
                    <div style="width: 80px; height: 80px; border: 1px dashed #ccc; line-height: 80px; font-size: 8pt; color: #999;">LOGO 2</div>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <div class="content">
        <?php echo $content; ?>

    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\Koperasi\resources\views/documents/pdf_template.blade.php ENDPATH**/ ?>