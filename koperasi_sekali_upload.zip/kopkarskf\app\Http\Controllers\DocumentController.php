<?php

namespace App\Http\Controllers;

use App\Models\DocumentTemplate;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

use App\Services\WhatsappService;

class DocumentController extends Controller
{
    /**
     * Send WA notification to members with pending credits
     */
    public function whatsappNotify(Request $request, DocumentTemplate $template)
    {
        if ($template->name !== 'Surat Pemotongan Payroll Kredit Mart') {
            return response()->json(['success' => false, 'message' => 'Fungsi ini hanya untuk dokumen Kredit Mart.'], 400);
        }

        $rawPeriode = $request->periode; // YYYY-MM
        if (!$rawPeriode) {
            return response()->json(['success' => false, 'message' => 'Periode harus dipilih.'], 400);
        }

        $dateParts = explode('-', $rawPeriode);
        $year = $dateParts[0];
        $month = $dateParts[1];

        $credits = \App\Models\Transaction::with('user')
            ->where('payment_method', 'kredit')
            ->where('status', 'credit')
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->get()
            ->groupBy('user_id');

        if ($credits->isEmpty()) {
            return response()->json(['success' => false, 'message' => 'Tidak ada tagihan kredit pada periode ini.'], 404);
        }

        $waService = app(WhatsappService::class);
        $months = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
        $periodeStr = $months[(int)$month] . ' ' . $year;
        
        $successCount = 0;
        $failCount = 0;

        foreach ($credits as $userId => $userTransactions) {
            $user = $userTransactions->first()->user;
            if (!$user || !$user->phone) {
                $failCount++;
                continue;
            }

            $totalAmount = $userTransactions->sum('total_amount');
            $formattedAmount = number_format($totalAmount, 0, ',', '.');

            $message = "*[Pemberitahuan Koperasi]*\n\n";
            $message .= "Halo Saudara/i *{$user->name}*,\n\n";
            $message .= "Kami informasikan bahwa terdapat tagihan *Kredit Mart* yang belum lunas untuk periode *{$periodeStr}* sebesar:\n";
            $message .= "*Rp {$formattedAmount}*\n\n";
            $message .= "Tagihan ini akan diajukan untuk *Pemotongan Payroll* bulan ini. Mohon pastikan nominal tersebut sudah sesuai.\n\n";
            $message .= "Jika terdapat ketidaksesuaian, mohon segera konfirmasi ke Pengurus Koperasi dalam waktu *2 x 24 jam*. Jika tidak ada konfirmasi, maka tagihan dianggap menyetujui dan akan diproses potong gaji.\n\n";
            $message .= "Terima kasih.\n\n";
            $message .= "_Pesan otomatis sistem Koperasi SPINDO Karawang Factory_";

            if ($waService->sendMessage($user->phone, $message)) {
                $successCount++;
            } else {
                $failCount++;
            }
        }

        return response()->json([
            'success' => true,
            'message' => "Notifikasi berhasil dikirim ke {$successCount} anggota." . ($failCount > 0 ? " ({$failCount} gagal/tidak ada no WA)" : "")
        ]);
    }

    public function index()
    {
        $templates = DocumentTemplate::all()
            ->groupBy('type')
            ->sortBy(function ($group, $type) {
                return $type === 'official' ? 0 : 1;
            });

        return view('documents.index', compact('templates'));
    }

    public function create(DocumentTemplate $template)
    {
        $placeholders = json_decode($template->placeholders, true) ?: [];
        return view('documents.create', compact('template', 'placeholders'));
    }

    public function generate(Request $request, DocumentTemplate $template)
    {
        $data = $request->except(['_token']);
        
        // Add default dynamic placeholders
        $now = Carbon::now();
        $days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        $months = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
        
        $data['today'] = $now->format('d/m/Y');
        $data['today_full'] = $now->day . ' ' . $months[$now->month] . ' ' . $now->year;
        $data['day_name'] = $days[$now->dayOfWeek];
        $data['month'] = $now->format('m');
        $data['month_name'] = $months[$now->month];
        $data['year'] = $now->year;

        $content = $template->content;
        
        // Format 'periode' if present (converting YYYY-MM to Month Year)
        if (isset($data['periode']) && preg_match('/^\d{4}-\d{2}$/', $data['periode'])) {
            $months = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
            $dateParts = explode('-', $data['periode']);
            $year = $dateParts[0];
            $month = (int)$dateParts[1];
            $data['periode'] = $months[$month] . ' ' . $year;
        }

        // Handle special logic for Payroll Deduction documents
        if ($template->name === 'Surat Pemotongan Payroll Simpanan Wajib') {
            $members = \App\Models\Member::with('user')
                ->where('status', 'active')
                ->get()
                ->sortBy('user.name')
                ->values();
            
            $mandatoryAmount = \App\Models\Setting::get('saving_mandatory', 100000);
            
            $table = '<table style="width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 8pt;">';
            $table .= '<thead style="background-color: #f3f4f6;">';
            $table .= '<tr>';
            $table .= '<th style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: center; width: 30px;">No</th>';
            $table .= '<th style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: left;">Nama Anggota</th>';
            $table .= '<th style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: center; width: 100px;">NIK</th>';
            $table .= '<th style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: right; width: 100px;">Nominal (Rp)</th>';
            $table .= '</tr>';
            $table .= '</thead>';
            $table .= '<tbody>';
            
            $total = 0;
            foreach ($members as $index => $member) {
                $table .= '<tr>';
                $table .= '<td style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: center;">' . ($index + 1) . '</td>';
                $table .= '<td style="border: 1px solid #d1d5db; padding: 4px 8px;">' . ($member->user->name ?? '-') . '</td>';
                $table .= '<td style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: center;">' . ($member->employee_id ?? '-') . '</td>';
                $table .= '<td style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: right;">' . number_format($mandatoryAmount, 0, ',', '.') . '</td>';
                $table .= '</tr>';
                $total += $mandatoryAmount;
            }
            
            $table .= '</tbody>';
            $table .= '<tfoot style="background-color: #f9fafb; font-weight: bold;">';
            $table .= '<tr>';
            $table .= '<td colspan="3" style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: right;">TOTAL</td>';
            $table .= '<td style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: right;">' . number_format($total, 0, ',', '.') . '</td>';
            $table .= '</tr>';
            $table .= '</tfoot>';
            $table .= '</table>';
            
            $data['lampiran_anggota'] = $table;
        } elseif ($template->name === 'Surat Pemotongan Payroll Kredit Mart') {
            // Get period from the formatted string or raw if possible
            // We assume $data['periode'] has been formatted to 'Month Year'
            // We need to parse it back or use the request
            $rawPeriode = $request->periode; // YYYY-MM
            $dateParts = explode('-', $rawPeriode);
            $year = $dateParts[0];
            $month = $dateParts[1];

            $credits = \App\Models\Transaction::with('user.member')
                ->where('payment_method', 'kredit')
                ->where('status', 'credit')
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->get()
                ->groupBy('user_id');

            $table = '<table style="width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 8pt;">';
            $table .= '<thead style="background-color: #f3f4f6;">';
            $table .= '<tr>';
            $table .= '<th style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: center; width: 30px;">No</th>';
            $table .= '<th style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: left;">Nama Anggota</th>';
            $table .= '<th style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: center; width: 100px;">NIK</th>';
            $table .= '<th style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: right; width: 100px;">Total Kredit (Rp)</th>';
            $table .= '</tr>';
            $table .= '</thead>';
            $table .= '<tbody>';

            $grandTotal = 0;
            $index = 1;
            
            // Sort grouped result by user name
            $sortedCredits = $credits->sortBy(function($group) {
                return $group->first()->user->name ?? '';
            });

            foreach ($sortedCredits as $userId => $userTransactions) {
                $user = $userTransactions->first()->user;
                $totalAmount = $userTransactions->sum('total_amount');
                
                $table .= '<tr>';
                $table .= '<td style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: center;">' . $index++ . '</td>';
                $table .= '<td style="border: 1px solid #d1d5db; padding: 4px 8px;">' . ($user->name ?? '-') . '</td>';
                $table .= '<td style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: center;">' . ($user->member->employee_id ?? '-') . '</td>';
                $table .= '<td style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: right;">' . number_format($totalAmount, 0, ',', '.') . '</td>';
                $table .= '</tr>';
                $grandTotal += $totalAmount;
            }

            if ($sortedCredits->isEmpty()) {
                $table .= '<tr><td colspan="4" style="border: 1px solid #d1d5db; padding: 10px; text-align: center;">Tidak ada data transaksi kredit untuk periode ini.</td></tr>';
            }

            $table .= '</tbody>';
            $table .= '<tfoot style="background-color: #f9fafb; font-weight: bold;">';
            $table .= '<tr>';
            $table .= '<td colspan="3" style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: right;">TOTAL</td>';
            $table .= '<td style="border: 1px solid #d1d5db; padding: 4px 8px; text-align: right;">' . number_format($grandTotal, 0, ',', '.') . '</td>';
            $table .= '</tr>';
            $table .= '</tfoot>';
            $table .= '</table>';

            $data['lampiran_anggota'] = $table;
        }

        foreach ($data as $key => $value) {
            $content = str_replace('{{' . $key . '}}', $value, $content);
        }

        // Fetch logos from settings
        $logo1 = \App\Models\Setting::get('doc_logo_1');
        $logo2 = \App\Models\Setting::get('doc_logo_2');

        // Convert to base64 for DomPDF compatibility
        $logo1Base64 = null;
        if ($logo1 && file_exists(public_path('storage/' . $logo1))) {
            $type = pathinfo(public_path('storage/' . $logo1), PATHINFO_EXTENSION);
            $data = file_get_contents(public_path('storage/' . $logo1));
            $logo1Base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
        }

        $logo2Base64 = null;
        if ($logo2 && file_exists(public_path('storage/' . $logo2))) {
            $type = pathinfo(public_path('storage/' . $logo2), PATHINFO_EXTENSION);
            $data = file_get_contents(public_path('storage/' . $logo2));
            $logo2Base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
        }

        $pdf = Pdf::loadView('documents.pdf_template', [
            'content' => $content,
            'title' => $template->name,
            'logo1' => $logo1Base64,
            'logo2' => $logo2Base64
        ]);

        return $pdf->stream($template->name . '_' . $now->format('YmdHis') . '.pdf');
    }
}
