<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk - {{ $transaction->invoice_number }}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            width: 80mm;
            padding: 10px;
            background: white;
        }
        .receipt {
            width: 100%;
        }
        .header {
            text-align: center;
            border-bottom: 1px dashed #000;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }
        .header h1 {
            font-size: 16px;
            font-weight: bold;
        }
        .header p {
            font-size: 10px;
            color: #666;
        }
        .info {
            margin-bottom: 10px;
            font-size: 11px;
        }
        .info p {
            display: flex;
            justify-content: space-between;
        }
        .items {
            border-top: 1px dashed #000;
            border-bottom: 1px dashed #000;
            padding: 10px 0;
            margin-bottom: 10px;
        }
        .item {
            margin-bottom: 8px;
        }
        .item-name {
            font-weight: bold;
        }
        .item-details {
            display: flex;
            justify-content: space-between;
            padding-left: 10px;
            font-size: 11px;
        }
        .totals {
            margin-bottom: 10px;
        }
        .totals p {
            display: flex;
            justify-content: space-between;
        }
        .totals .grand-total {
            font-size: 14px;
            font-weight: bold;
            border-top: 1px solid #000;
            padding-top: 5px;
            margin-top: 5px;
        }
        .footer {
            text-align: center;
            border-top: 1px dashed #000;
            padding-top: 10px;
            font-size: 10px;
        }
        .footer p {
            margin-bottom: 3px;
        }
        @media print {
            body {
                width: 80mm;
            }
            .no-print {
                display: none !important;
            }
        }
        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
        }
        .print-btn:hover {
            background: #2563eb;
        }
    </style>
</head>
<body>
    <button class="print-btn no-print" onclick="window.print()">🖨️ Cetak Struk</button>

    <div class="receipt">
        <div class="header">
            <h1>KOPERASI MART</h1>
            <p>Jl. Contoh Alamat No. 123</p>
            <p>Telp: (021) 1234567</p>
        </div>

        <div class="info">
            <p><span>No. Invoice:</span> <span>{{ $transaction->invoice_number }}</span></p>
            <p><span>Tanggal:</span> <span>{{ $transaction->created_at->format('d/m/Y H:i') }}</span></p>
            <p><span>Pembeli:</span> <span>{{ $transaction->user->name ?? 'Tamu' }}</span></p>
            <p><span>Kasir:</span> <span>{{ $transaction->cashier->name ?? '-' }}</span></p>
            <p><span>Metode:</span> <span>{{ strtoupper(str_replace('_', ' ', $transaction->payment_method)) }}</span></p>
        </div>

        <div class="items">
            @foreach($transaction->items as $item)
            <div class="item">
                <div class="item-name">{{ $item->product->name ?? 'Produk' }}</div>
                <div class="item-details">
                    <span>{{ $item->quantity }} x Rp {{ number_format($item->price, 0, ',', '.') }}</span>
                    <span>Rp {{ number_format($item->subtotal, 0, ',', '.') }}</span>
                </div>
            </div>
            @endforeach
        </div>

        <div class="totals">
            <p>
                <span>Subtotal ({{ $transaction->items->sum('quantity') }} item):</span>
                <span>Rp {{ number_format($transaction->total_amount, 0, ',', '.') }}</span>
            </p>
            <p class="grand-total">
                <span>TOTAL:</span>
                <span>Rp {{ number_format($transaction->total_amount, 0, ',', '.') }}</span>
            </p>
            <p>
                <span>Bayar:</span>
                <span>Rp {{ number_format($transaction->paid_amount, 0, ',', '.') }}</span>
            </p>
            <p>
                <span>Kembali:</span>
                <span>Rp {{ number_format($transaction->change_amount, 0, ',', '.') }}</span>
            </p>
        </div>

        <div class="footer">
            <p>================================</p>
            <p>Terima kasih atas kunjungan Anda!</p>
            <p>Barang yang sudah dibeli tidak dapat dikembalikan.</p>
            <p>================================</p>
            <p style="margin-top: 10px; font-size: 9px;">Dicetak: {{ now()->format('d/m/Y H:i:s') }}</p>
        </div>
    </div>

    <script>
        // Auto print on load (optional - uncomment if needed)
        // window.onload = function() { window.print(); }
    </script>
</body>
</html>
