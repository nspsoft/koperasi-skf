@extends('layouts.app')

@section('title', 'Laporan Kredit - Koperasi Mart')

@section('content')
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">📝 Laporan Kredit Mart</h1>
            <p class="page-subtitle">Daftar transaksi kredit member yang belum dan sudah dilunasi</p>
        </div>
        <div class="flex gap-2">
            <a href="{{ route('pos.index') }}" class="btn-secondary">
                🛒 Kasir POS
            </a>
            <a href="{{ route('pos.history') }}" class="btn-secondary">
                📋 Riwayat
            </a>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div class="glass-card-solid p-5">
            <div class="flex items-center gap-4">
                <div class="w-14 h-14 rounded-xl bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                    <span class="text-2xl">📋</span>
                </div>
                <div>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Kredit Belum Lunas</p>
                    <p class="text-2xl font-bold text-orange-600">{{ $pendingCount }}</p>
                    <p class="text-xs text-gray-400">Transaksi</p>
                </div>
            </div>
        </div>
        <div class="glass-card-solid p-5">
            <div class="flex items-center gap-4">
                <div class="w-14 h-14 rounded-xl bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                    <span class="text-2xl">💰</span>
                </div>
                <div>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Total Belum Lunas</p>
                    <p class="text-2xl font-bold text-red-600">Rp {{ number_format($totalPending, 0, ',', '.') }}</p>
                </div>
            </div>
        </div>
        <div class="glass-card-solid p-5">
            <div class="flex items-center gap-4">
                <div class="w-14 h-14 rounded-xl bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <span class="text-2xl">✅</span>
                </div>
                <div>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Total Sudah Lunas</p>
                    <p class="text-2xl font-bold text-green-600">Rp {{ number_format($totalPaid, 0, ',', '.') }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="glass-card-solid p-4 mb-6">
        <form method="GET" class="flex flex-wrap gap-4 items-end">
            <div class="min-w-[150px]">
                <label class="form-label text-sm">Status</label>
                <select name="status" class="form-input py-2 w-full">
                    <option value="">Belum Lunas</option>
                    <option value="completed" {{ request('status') == 'completed' ? 'selected' : '' }}>Sudah Lunas</option>
                    <option value="all" {{ request('status') == 'all' ? 'selected' : '' }}>Semua</option>
                </select>
            </div>
            <div class="min-w-[150px]">
                <label class="form-label text-sm">Dari Tanggal</label>
                <input type="date" name="from_date" value="{{ request('from_date') }}" class="form-input py-2 w-full">
            </div>
            <div class="min-w-[150px]">
                <label class="form-label text-sm">Sampai Tanggal</label>
                <input type="date" name="to_date" value="{{ request('to_date') }}" class="form-input py-2 w-full">
            </div>
            <div class="flex gap-2">
                <button type="submit" class="btn-primary py-2 px-4">
                    🔍 Filter
                </button>
                <a href="{{ route('pos.credits') }}" class="btn-secondary py-2 px-4">Reset</a>
            </div>
        </form>
    </div>

    <!-- Credits Table -->
    <div class="glass-card-solid overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">Invoice</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">Tanggal</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">Member</th>
                        <th class="px-4 py-3 text-right text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">Total</th>
                        <th class="px-4 py-3 text-center text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">Status</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">Kasir</th>
                        <th class="px-4 py-3 text-center text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider w-28">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    @forelse($credits as $credit)
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                        <td class="px-4 py-4">
                            <span class="font-mono text-sm font-semibold text-primary-600">{{ $credit->invoice_number }}</span>
                            <div class="text-xs text-gray-400 mt-0.5">{{ $credit->items->count() }} item</div>
                        </td>
                        <td class="px-4 py-4">
                            <div class="text-sm font-medium text-gray-900 dark:text-white">{{ $credit->created_at->format('d/m/Y') }}</div>
                            <div class="text-xs text-gray-500">{{ $credit->created_at->format('H:i') }} WIB</div>
                        </td>
                        <td class="px-4 py-4">
                            @if($credit->user)
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-600 flex items-center justify-center font-bold text-sm">
                                        {{ strtoupper(substr($credit->user->name, 0, 1)) }}
                                    </div>
                                    <div>
                                        <div class="font-medium text-gray-900 dark:text-white text-sm">{{ $credit->user->name }}</div>
                                        <div class="text-xs text-gray-500">{{ $credit->user->member->member_id ?? '-' }}</div>
                                    </div>
                                </div>
                            @else
                                <span class="text-gray-400">-</span>
                            @endif
                        </td>
                        <td class="px-4 py-4 text-right">
                            <span class="text-lg font-bold text-gray-900 dark:text-white">Rp {{ number_format($credit->total_amount, 0, ',', '.') }}</span>
                        </td>
                        <td class="px-4 py-4 text-center">
                            @if($credit->status === 'credit')
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400">
                                    ⏳ Belum Lunas
                                </span>
                            @else
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                    ✓ Lunas
                                </span>
                            @endif
                        </td>
                        <td class="px-4 py-4">
                            <span class="text-sm text-gray-600 dark:text-gray-400">{{ $credit->cashier->name ?? '-' }}</span>
                        </td>
                        <td class="px-4 py-4 text-center">
                            @if($credit->status === 'credit')
                                <button onclick="openPaymentModal({{ $credit->id }}, '{{ $credit->invoice_number }}', {{ $credit->total_amount }}, '{{ addslashes($credit->user->name ?? 'Unknown') }}')" 
                                        class="inline-flex items-center gap-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg transition-colors">
                                    💰 Lunasi
                                </button>
                            @else
                                <span class="text-green-500" title="{{ $credit->notes }}">
                                    <svg class="w-6 h-6 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                </span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center py-12 text-gray-500">
                            <span class="text-5xl block mb-3">📝</span>
                            <p class="text-lg font-medium">Tidak ada data kredit</p>
                            <p class="text-sm text-gray-400 mt-1">Belum ada transaksi kredit yang ditemukan</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        
        @if($credits->hasPages())
        <div class="p-4 border-t border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
            {{ $credits->withQueryString()->links() }}
        </div>
        @endif
    </div>

    <!-- Payment Modal -->
    <div id="paymentModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="fixed inset-0 bg-black/50 backdrop-blur-sm" onclick="closePaymentModal()"></div>
            <div class="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-md mx-auto transform transition-all">
                <form id="paymentForm" method="POST">
                    @csrf
                    <div class="p-6">
                        <div class="flex items-center gap-3 mb-5">
                            <div class="w-12 h-12 rounded-xl bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                                <span class="text-2xl">💰</span>
                            </div>
                            <div>
                                <h3 class="text-lg font-bold text-gray-900 dark:text-white">Pelunasan Kredit</h3>
                                <p class="text-sm text-gray-500">Konfirmasi pembayaran hutang</p>
                            </div>
                        </div>
                        
                        <div class="bg-gray-50 dark:bg-gray-900 rounded-xl p-4 mb-5 space-y-2">
                            <div class="flex justify-between">
                                <span class="text-gray-500 dark:text-gray-400">Invoice</span>
                                <span id="modalInvoice" class="font-mono font-semibold text-gray-900 dark:text-white"></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-500 dark:text-gray-400">Member</span>
                                <span id="modalMember" class="font-medium text-gray-900 dark:text-white"></span>
                            </div>
                            <div class="flex justify-between pt-2 border-t border-gray-200 dark:border-gray-700">
                                <span class="text-lg font-bold text-gray-900 dark:text-white">Total Bayar</span>
                                <span id="modalAmount" class="text-lg font-bold text-green-600"></span>
                            </div>
                        </div>

                        <div class="mb-5">
                            <label class="form-label mb-2">Metode Pembayaran</label>
                            <div class="grid grid-cols-3 gap-3">
                                <label class="cursor-pointer">
                                    <input type="radio" name="payment_method" value="cash" class="sr-only peer" checked>
                                    <div class="p-4 text-center border-2 rounded-xl peer-checked:border-green-500 peer-checked:bg-green-50 dark:peer-checked:bg-green-900/20 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                        <span class="text-2xl block mb-1">💵</span>
                                        <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Tunai</span>
                                    </div>
                                </label>
                                <label class="cursor-pointer">
                                    <input type="radio" name="payment_method" value="transfer" class="sr-only peer">
                                    <div class="p-4 text-center border-2 rounded-xl peer-checked:border-blue-500 peer-checked:bg-blue-50 dark:peer-checked:bg-blue-900/20 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                        <span class="text-2xl block mb-1">🏦</span>
                                        <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Transfer</span>
                                    </div>
                                </label>
                                <label class="cursor-pointer">
                                    <input type="radio" name="payment_method" value="saldo" class="sr-only peer">
                                    <div class="p-4 text-center border-2 rounded-xl peer-checked:border-purple-500 peer-checked:bg-purple-50 dark:peer-checked:bg-purple-900/20 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                        <span class="text-2xl block mb-1">💳</span>
                                        <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Saldo</span>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <div>
                            <label class="form-label">Catatan (Opsional)</label>
                            <textarea name="notes" rows="2" class="form-input" placeholder="Catatan tambahan..."></textarea>
                        </div>
                    </div>
                    <div class="flex gap-3 p-5 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 rounded-b-2xl">
                        <button type="button" onclick="closePaymentModal()" class="flex-1 btn-secondary py-2.5">Batal</button>
                        <button type="submit" class="flex-1 btn-primary py-2.5">✅ Konfirmasi Lunas</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @push('scripts')
    <script>
        function openPaymentModal(id, invoice, amount, member) {
            document.getElementById('paymentForm').action = '/pos/credits/' + id + '/pay';
            document.getElementById('modalInvoice').textContent = invoice;
            document.getElementById('modalMember').textContent = member;
            document.getElementById('modalAmount').textContent = 'Rp ' + amount.toLocaleString('id-ID');
            document.getElementById('paymentModal').classList.remove('hidden');
        }

        function closePaymentModal() {
            document.getElementById('paymentModal').classList.add('hidden');
        }
    </script>
    @endpush
@endsection
