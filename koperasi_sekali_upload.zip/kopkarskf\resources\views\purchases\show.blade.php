@extends('layouts.app')

@section('title', 'Detail Pembelian ' . $purchase->reference_number)

@section('content')
<div class="max-w-4xl mx-auto space-y-6">
    <div class="flex items-center gap-4 mb-6">
        <a href="{{ route('purchases.index') }}" class="btn-secondary-sm">
            ← Kembali
        </a>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Detail Pembelian</h1>
    </div>

    <!-- Status Banner -->
    <div class="glass-card p-6 border-l-4 border-{{ $purchase->status_color }}-500">
        <div class="flex justify-between items-start">
            <div>
                <p class="text-sm text-gray-500 uppercase">Status & No. PO</p>
                <div class="flex items-center gap-3 mt-1">
                    <span class="text-2xl font-bold text-gray-900 dark:text-white">{{ $purchase->reference_number }}</span>
                    <span class="badge badge-{{ $purchase->status_color }} text-lg">{{ $purchase->status_label }}</span>
                </div>
                @if($purchase->status === 'completed')
                <p class="text-sm text-green-600 mt-2">✓ Selesai pada {{ $purchase->completed_at->format('d M Y H:i') }}</p>
                @endif
            </div>
            
            @if($purchase->status === 'pending')
            <div class="flex gap-2">
                <form action="{{ route('purchases.update-status', $purchase) }}" method="POST" onsubmit="return confirm('Yakin batalkan pembelian ini?')">
                    @csrf
                    @method('PATCH')
                    <input type="hidden" name="status" value="cancelled">
                    <button type="submit" class="btn-danger">Batalkan</button>
                </form>
                <form action="{{ route('purchases.update-status', $purchase) }}" method="POST" onsubmit="return confirm('Konfirmasi penerimaan barang? Stok akan ditambahkan otomatis.')">
                    @csrf
                    @method('PATCH')
                    <input type="hidden" name="status" value="completed">
                    <button type="submit" class="btn-success">
                        ✓ Terima Barang (Selesai)
                    </button>
                </form>
            </div>
            @endif
        </div>
    </div>

    <!-- Details -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="glass-card p-4">
            <h3 class="font-bold text-gray-900 dark:text-white mb-3 text-sm uppercase tracking-wide border-b pb-2">Informasi Supplier</h3>
            <p class="text-lg font-semibold">{{ $purchase->supplier->name }}</p>
            <p class="text-gray-600 dark:text-gray-400">{{ $purchase->supplier->address ?? '-' }}</p>
            <div class="mt-4 space-y-1 text-sm">
                <p class="flex justify-between">
                    <span class="text-gray-500">Kontak:</span>
                    <span class="font-medium">{{ $purchase->supplier->contact_person ?? '-' }}</span>
                </p>
                <p class="flex justify-between">
                    <span class="text-gray-500">Telepon:</span>
                    <span class="font-medium">{{ $purchase->supplier->phone ?? '-' }}</span>
                </p>
            </div>
        </div>

        <div class="glass-card p-4">
            <h3 class="font-bold text-gray-900 dark:text-white mb-3 text-sm uppercase tracking-wide border-b pb-2">Info Transaksi</h3>
            <div class="space-y-2 text-sm">
                <p class="flex justify-between">
                    <span class="text-gray-500">Tanggal Pembelian:</span>
                    <span class="font-medium">{{ $purchase->purchase_date->format('d F Y') }}</span>
                </p>
                <p class="flex justify-between">
                    <span class="text-gray-500">Dibuat Oleh:</span>
                    <span class="font-medium">{{ $purchase->creator->name ?? 'System' }}</span>
                </p>
                @if($purchase->note)
                <div class="mt-2 pt-2 border-t border-dashed">
                    <p class="text-gray-500 mb-1">Catatan:</p>
                    <p class="text-gray-800 dark:text-gray-300 italic">"{{ $purchase->note }}"</p>
                </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Items -->
    <div class="glass-card overflow-hidden">
        <div class="bg-gray-50 dark:bg-gray-700/50 p-3 border-b border-gray-100 dark:border-gray-700">
            <h3 class="font-bold text-gray-900 dark:text-white">Item Pembelian</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="table-modern">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th class="text-center">Qty</th>
                        <th class="text-right">Harga Satuan</th>
                        <th class="text-right">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($purchase->items as $item)
                    <tr>
                        <td>
                            <div class="flex items-center gap-3">
                                @if($item->product->image)
                                <img src="{{ \Storage::url($item->product->image) }}" class="w-10 h-10 rounded object-cover">
                                @else
                                <div class="w-10 h-10 bg-gray-200 rounded flex items-center justify-center text-xs">No Img</div>
                                @endif
                                <div>
                                    <div class="font-medium text-gray-900 dark:text-white">{{ $item->product->name }}</div>
                                    <div class="text-xs text-gray-500">{{ $item->product->code }}</div>
                                </div>
                            </div>
                        </td>
                        <td class="text-center">{{ $item->quantity }}</td>
                        <td class="text-right text-gray-600">Rp {{ number_format($item->cost, 0, ',', '.') }}</td>
                        <td class="text-right font-medium">Rp {{ number_format($item->subtotal, 0, ',', '.') }}</td>
                    </tr>
                    @endforeach
                </tbody>
                <tfoot class="bg-gray-50 dark:bg-gray-700/50">
                    <tr>
                        <td colspan="3" class="text-right font-bold py-4 px-6">TOTAL PEMBELIAN</td>
                        <td class="text-right font-bold py-4 px-6 text-xl text-primary-600">
                            Rp {{ number_format($purchase->total_amount, 0, ',', '.') }}
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
@endsection
