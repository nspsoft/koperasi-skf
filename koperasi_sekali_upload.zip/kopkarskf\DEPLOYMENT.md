# 🚀 Panduan Deployment Production

Dokumen ini berisi langkah-langkah untuk deployment aplikasi Koperasi ke environment production.

---

## 📋 Pre-Requisites

- PHP 8.2+
- MySQL 8.0+ / MariaDB 10.5+
- Composer
- Node.js & NPM (untuk build assets)
- Web Server (Apache/Nginx)
- SSL Certificate (HTTPS)

---

## 🔧 Langkah-Langkah Deployment

### 1. Persiapan Server

```bash
# Clone repository
git clone [your-repo] /var/www/koperasi

# Masuk ke direktori
cd /var/www/koperasi

# Install dependencies
composer install --no-dev --optimize-autoloader
npm install && npm run build
```

### 2. Konfigurasi Environment

```bash
# Copy environment file
cp .env.example .env

# Generate application key
php artisan key:generate
```

Edit file `.env`:

```env
APP_NAME="Koperasi Karyawan"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://koperasi.yourdomain.com

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=koperasi_prod
DB_USERNAME=your_db_user
DB_PASSWORD=your_db_password

# Mail Configuration
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your_email@gmail.com
MAIL_PASSWORD=your_app_password
MAIL_FROM_ADDRESS=noreply@yourdomain.com
```

### 3. Setup Database Production

**Opsi A: Fresh Install (Recommended)**

```powershell
# Jalankan migrasi dan production seeder
php artisan migrate --force
php artisan db:seed --class=ProductionSeeder --force
```

**Opsi B: Menggunakan Artisan Command**

```powershell
# Reset untuk production (dengan fresh migration)
php artisan koperasi:reset-for-production --fresh --force
```

### 4. Set Permissions

```bash
# Linux/Mac
chmod -R 755 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache

# Windows (Laragon)
# Tidak perlu, Laragon otomatis handle
```

### 5. Optimize untuk Production

```powershell
# Cache konfigurasi
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Optimize autoloader
composer dump-autoload --optimize
```

---

## 🔐 Post-Deployment Checklist

- [ ] Login dengan akun admin default
- [ ] **GANTI PASSWORD ADMIN** (sangat penting!)
- [ ] Configure AI Settings (jika menggunakan)
- [ ] Configure WhatsApp Bot (jika menggunakan)
- [ ] Update Settings → Nama Koperasi, Logo, dll
- [ ] Import data anggota via Excel
- [ ] Test semua fitur utama

---

## 📊 Default Admin Credentials

| Field | Value |
|-------|-------|
| Email | `admin@koperasi.com` |
| Password | `admin123` |

> ⚠️ **WAJIB** ganti password setelah login pertama!

---

## 🔄 Perintah Artisan Berguna

### Reset untuk Production

```powershell
# Preview data yang akan dihapus
php artisan koperasi:reset-for-production

# Reset tanpa konfirmasi (untuk scripting)
php artisan koperasi:reset-for-production --force

# Reset + fresh migration
php artisan koperasi:reset-for-production --fresh --force

# Reset tapi pertahankan admin yang sudah ada
php artisan koperasi:reset-for-production --keep-admin
```

### Maintenance

```powershell
# Mode maintenance ON
php artisan down

# Mode maintenance OFF
php artisan up

# Clear all caches
php artisan optimize:clear
```

---

## 🔒 Security Recommendations

1. **Ganti Password Admin** - Wajib setelah deployment
2. **Aktifkan HTTPS** - Jangan jalankan tanpa SSL
3. **Database Backup** - Setup backup otomatis
4. **Rate Limiting** - Aktifkan throttling di middleware
5. **2FA** - Pertimbangkan menambahkan 2-factor auth

---

## 🆘 Troubleshooting

### Error: Permission denied

```bash
chmod -R 777 storage bootstrap/cache  # Sementara untuk debug
# Kembalikan ke 755 setelah fix
```

### Error: Class not found

```powershell
composer dump-autoload
php artisan optimize:clear
```

### Error: 500 Internal Server Error

1. Check `storage/logs/laravel.log`
2. Pastikan `APP_DEBUG=true` sementara untuk lihat error
3. Kembalikan ke `APP_DEBUG=false` setelah fix

---

## 📞 Support

Jika mengalami masalah, hubungi developer atau buka issue di repository.
