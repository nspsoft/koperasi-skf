@extends('layouts.app')

@section('title', 'User Acceptance Test (UAT)')

@section('content')
<style>
    @media print {
        /* Hide everything by default */
        body * {
            visibility: hidden;
        }

        /* Only show the print container and its children */
        #print-container, #print-container * {
            visibility: visible;
        }

        /* Position the print container */
        #print-container {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 0;
            background: white;
            color: black;
        }

        /* Hide unnecessary elements inside the print container */
        .no-print {
            display: none !important;
        }

        /* Print Header Styling */
        .print-header {
            display: flex !important;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e5e7eb;
            visibility: visible;
        }

        /* Ensure tables don't break awkwardly */
        table {
            page-break-inside: auto;
        }
        tr {
            page-break-inside: avoid;
            page-break-after: auto;
        }
        thead {
            display: table-header-group;
        }
        tfoot {
            display: table-footer-group;
        }
        
        /* Adjust page margins */
        @page {
            margin: 1.5cm;
            size: auto;
        }
    }
    
    /* Hide print header on screen */
    .print-header {
        display: none;
    }
</style>

<div class="space-y-6" id="print-container" x-data="{
    total: 0,
    checked: 0,
    init() {
        // Count total checkboxes on load
        this.total = document.querySelectorAll('.uat-checkbox').length;
        // Update total if strictly provided or just dynamic
    },
    updateCount() {
        this.checked = document.querySelectorAll('.uat-checkbox:checked').length;
    }
}">
    <!-- Print Only Header -->
    <div class="print-header">
        <div class="flex items-center gap-4">
            @if(isset($globalSettings['coop_logo']) && $globalSettings['coop_logo'])
                <img src="{{ Storage::url($globalSettings['coop_logo']) }}" alt="Logo" class="w-16 h-16 object-contain">
            @else
                <div class="w-16 h-16 bg-primary-100 text-primary-600 rounded-lg flex items-center justify-center">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                </div>
            @endif
            <div>
                <h1 class="text-2xl font-bold text-gray-900">{{ $globalSettings['coop_name'] ?? 'Koperasi Karyawan' }}</h1>
                <p class="text-gray-500">User Acceptance Test (UAT) Document</p>
            </div>
        </div>
        <div class="text-right text-sm text-gray-500">
            <p>Date: {{ date('d M Y') }}</p>
            <p>Rev: 1.0.0</p>
        </div>
    </div>

    <!-- Screen Header (Hidden on Print) -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div>
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Dokumen User Acceptance Test (UAT)</h1>
            <p class="text-gray-500 dark:text-gray-400">Ver. 1.0.0 - Koperasi Karyawan PT. SPINDO TBK</p>
        </div>
        <div>
            <button onclick="window.print()" class="no-print btn-primary flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
                Cetak Dokumen
            </button>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 no-print">
        <div class="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center text-2xl font-bold">
                8
            </div>
            <div>
                <p class="text-sm text-gray-500 dark:text-gray-400">Total Modul</p>
                <h4 class="text-xl font-bold text-gray-900 dark:text-white">Modules</h4>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 bg-green-100 text-green-600 rounded-xl flex items-center justify-center text-2xl font-bold">
                30+
            </div>
            <div>
                <p class="text-sm text-gray-500 dark:text-gray-400">Total Skenario</p>
                <h4 class="text-xl font-bold text-gray-900 dark:text-white">Scenarios</h4>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center text-2xl font-bold">
                💯
            </div>
            <div>
                <p class="text-sm text-gray-500 dark:text-gray-400">Cakupan Test</p>
                <h4 class="text-xl font-bold text-gray-900 dark:text-white">Coverage</h4>
            </div>
        </div>
    </div>

    <!-- Content -->
    <div class="bg-white dark:bg-gray-800 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm overflow-hidden">
        <div class="p-6 space-y-10">
            
            <!-- 1. Dashboard -->
            <div>
                <h4 class="font-bold text-lg text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                    <span class="w-8 h-8 bg-gray-100 text-gray-600 rounded-lg flex items-center justify-center text-sm">1</span>
                    Dashboard
                </h4>
                <div class="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
                        <thead class="bg-gray-50 dark:bg-gray-700/50">
                            <tr>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400 w-24">Kode</th>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400">Skenario Pengujian</th>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400">Ekspektasi Hasil</th>
                                <th class="px-4 py-3 text-center font-medium text-gray-500 dark:text-gray-400 w-24">Check</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-800">
                            <tr>
                                <td class="px-4 py-3 font-mono text-xs text-gray-500">DASH-01</td>
                                <td class="px-4 py-3 text-gray-900 dark:text-white">Admin Dashboard (Stats & Grafik)</td>
                                <td class="px-4 py-3 text-gray-600 dark:text-gray-400">Grafik & angka statistik tampil sesuai data real</td>
                                <td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600 shadow-sm focus:border-primary-300 focus:ring focus:ring-primary-200 focus:ring-opacity-50"></td>
                            </tr>
                            <tr>
                                <td class="px-4 py-3 font-mono text-xs text-gray-500">DASH-02</td>
                                <td class="px-4 py-3 text-gray-900 dark:text-white">Member Dashboard (Saldo)</td>
                                <td class="px-4 py-3 text-gray-600 dark:text-gray-400">Menampilkan saldo simpanan & pinjaman pribadi</td>
                                <td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600 shadow-sm focus:border-primary-300 focus:ring focus:ring-primary-200 focus:ring-opacity-50"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- 2. Keuangan -->
            <div>
                <h4 class="font-bold text-lg text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                    <span class="w-8 h-8 bg-amber-100 text-amber-600 rounded-lg flex items-center justify-center text-sm">2</span>
                    Keuangan & SHU
                </h4>
                <div class="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
                        <thead class="bg-gray-50 dark:bg-gray-700/50">
                            <tr>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400 w-24">Kode</th>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400">Skenario Pengujian</th>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400">Ekspektasi Hasil</th>
                                <th class="px-4 py-3 text-center font-medium text-gray-500 dark:text-gray-400 w-24">Check</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-800">
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">FIN-01</td><td class="px-4 py-3 text-gray-900 dark:text-white">Tambah Simpanan (Pokok/Wajib)</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Saldo bertambah, tercatat di mutasi</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">FIN-03</td><td class="px-4 py-3 text-gray-900 dark:text-white">Pengajuan & Approval Pinjaman</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Status Active, dana cair, jadwal angsuran terbentuk</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">FIN-06</td><td class="px-4 py-3 text-gray-900 dark:text-white">Bayar Angsuran</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Sisa pokok berkurang, history pembayaran tersimpan</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">FIN-07</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Penarikan Saldo Sukarela</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Saldo terpotong setelah approval admin</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">FIN-09</td><td class="px-4 py-3 text-gray-900 dark:text-white">Kalkulasi & Distribusi SHU</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">SHU terbagi ke akun member sesuai rumus</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- 3. Koperasi Mart -->
            <div>
                <h4 class="font-bold text-lg text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                    <span class="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center text-sm">3</span>
                    Koperasi Mart & Inventory
                </h4>
                <div class="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
                        <thead class="bg-gray-50 dark:bg-gray-700/50">
                            <tr>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400 w-24">Kode</th>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400">Skenario Pengujian</th>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400">Ekspektasi Hasil</th>
                                <th class="px-4 py-3 text-center font-medium text-gray-500 dark:text-gray-400 w-24">Check</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-800">
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">POS-01</td><td class="px-4 py-3 text-gray-900 dark:text-white">Transaksi POS Cash/Saldo</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Struk keluar, stok berkurang, saldo member terpotong</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">INV-01</td><td class="px-4 py-3 text-gray-900 dark:text-white">Manajemen Produk (CRUD)</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Produk tampil di katalog POS & Online</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">INV-03</td><td class="px-4 py-3 text-gray-900 dark:text-white">Low Stock Alert</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Notifikasi muncul saat stok < min. stock</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">INV-05</td><td class="px-4 py-3 text-gray-900 dark:text-white">Stock Opname Process</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Selisih stok (system vs actual) terhitung otomatis</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">INV-06</td><td class="px-4 py-3 text-gray-900 dark:text-white">Stock Opname Export</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Excel terunduh dengan baris total & highlight selisih</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- 4. Belanja Member -->
            <div>
                <h4 class="font-bold text-lg text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                    <span class="w-8 h-8 bg-green-100 text-green-600 rounded-lg flex items-center justify-center text-sm">4</span>
                    Belanja Online (Member)
                </h4>
                <div class="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
                        <thead class="bg-gray-50 dark:bg-gray-700/50">
                            <tr>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400 w-24">Kode</th>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400">Skenario Pengujian</th>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400">Ekspektasi Hasil</th>
                                <th class="px-4 py-3 text-center font-medium text-gray-500 dark:text-gray-400 w-24">Check</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-800">
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">SHP-01</td><td class="px-4 py-3 text-gray-900 dark:text-white">Katalog & Pencarian</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Menampilkan hasil pencarian yang relevan</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">SHP-02</td><td class="px-4 py-3 text-gray-900 dark:text-white">Add to Cart & Checkout</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Order masuk sistem, stok terbooking</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">SHP-04</td><td class="px-4 py-3 text-gray-900 dark:text-white">Tracking Order</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Status pesanan terpantau (Pending/Process/Done)</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- 5. Admin System -->
            <div>
                <h4 class="font-bold text-lg text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                    <span class="w-8 h-8 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center text-sm">5</span>
                    System & Settings
                </h4>
                <div class="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
                        <thead class="bg-gray-50 dark:bg-gray-700/50">
                            <tr>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400 w-24">Kode</th>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400">Skenario Pengujian</th>
                                <th class="px-4 py-3 text-left font-medium text-gray-500 dark:text-gray-400">Ekspektasi Hasil</th>
                                <th class="px-4 py-3 text-center font-medium text-gray-500 dark:text-gray-400 w-24">Check</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-800">
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">ADM-03</td><td class="px-4 py-3 text-gray-900 dark:text-white">Import Data (Anggota/Saldo)</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Data massal masuk ke database via Excel</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">ADM-05</td><td class="px-4 py-3 text-gray-900 dark:text-white">Branding (Logo & Nama)</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Title tab & Favicon berubah sesuai setting</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">INF-03</td><td class="px-4 py-3 text-gray-900 dark:text-white">Download AD/ART PDF</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">Dokumen terunduh dengan format resmi & kop</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                            <tr><td class="px-4 py-3 font-mono text-xs text-gray-500">ADM-07</td><td class="px-4 py-3 text-gray-900 dark:text-white">Backup Database</td><td class="px-4 py-3 text-gray-600 dark:text-gray-400">File .sql terunduh aman</td><td class="px-4 py-3 text-center"><input type="checkbox" @change="updateCount()" class="uat-checkbox w-5 h-5 rounded border-gray-300 text-primary-600"></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Resume Hasil Testing -->
        <div class="px-6 py-4 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700">
            <h4 class="font-bold text-lg text-gray-900 dark:text-white mb-4">Resume Hasil Testing</h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-4">
                    <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Total Skenario</span>
                        <input type="number" readonly :value="total" class="w-20 text-right bg-transparent border-0 border-b border-gray-300 focus:ring-0 text-sm font-bold">
                    </div>
                    <div class="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/10 rounded-lg">
                        <span class="text-sm font-medium text-green-700 dark:text-green-300">Skenario Passed (OK)</span>
                        <input type="number" readonly :value="checked" class="w-20 text-right bg-transparent border-0 border-b border-green-300 focus:ring-0 text-green-700 font-bold">
                    </div>
                    <div class="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/10 rounded-lg">
                        <span class="text-sm font-medium text-red-700 dark:text-red-300">Skenario Failed (Not OK)</span>
                        <input type="number" readonly :value="total - checked" class="w-20 text-right bg-transparent border-0 border-b border-red-300 focus:ring-0 text-red-700 font-bold">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">Catatan Tambahan / Rekomendasi</label>
                    <textarea rows="5" class="w-full rounded-lg border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm focus:border-primary-500 focus:ring-primary-500 text-sm" placeholder="Tulis catatan hasil testing di sini..."></textarea>
                </div>
            </div>
        </div>
        <div class="px-6 py-6 bg-gray-50 dark:bg-gray-800/50 border-t border-gray-100 dark:border-gray-700 text-center">
            <p class="text-sm text-gray-600 dark:text-gray-400 mb-4">Pastikan semua checkbox telah tercentang sebelum melakukan sign-off dokumen.</p>
            <div class="flex justify-center gap-4">
                <div class="border border-dashed border-gray-300 dark:border-gray-600 p-4 rounded-lg w-48 h-24"></div>
                <div class="border border-dashed border-gray-300 dark:border-gray-600 p-4 rounded-lg w-48 h-24"></div>
            </div>
            <div class="flex justify-center gap-4 mt-2 text-xs text-gray-500">
                <div class="w-48 text-center">Tanda Tangan User</div>
                <div class="w-48 text-center">Tanda Tangan Developer</div>
            </div>
        </div>
    </div>
</div>
@endsection
