<?php
/**
 * Laravel Deployment Fixer/Diagnostic Tool
 * Upload this to your public_html/ folder and access it via yourbrowser.com/fix.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Laravel Shared Hosting Fixer</h1>";

// 1. Check Paths
$basePath = realpath(__DIR__ . '/../kopkarskf'); // Adjust if folder name is different
echo "<h2>1. Checking Paths</h2>";
if ($basePath && is_dir($basePath)) {
    echo "<p style='color:green'>Found Laravel root at: $basePath</p>";
} else {
    echo "<p style='color:red'>FAILED: Could not find Laravel root folder. Please check if 'kopkarskf' folder is next to public_html.</p>";
    exit;
}

// 2. Clear Cache & Bootstrap
echo "<h2>2. Clearing Cache</h2>";
$cacheFiles = [
    $basePath . '/bootstrap/cache/config.php',
    $basePath . '/bootstrap/cache/routes.php',
    $basePath . '/bootstrap/cache/services.php',
    $basePath . '/bootstrap/cache/packages.php',
];

foreach ($cacheFiles as $file) {
    if (file_exists($file)) {
        if (unlink($file)) {
            echo "<p>Deleted: $file</p>";
        } else {
            echo "<p style='color:orange'>Could not delete: $file (Permission issue?)</p>";
        }
    }
}

// 3. Fix Permissions
echo "<h2>3. Fixing Permissions</h2>";
$pathsToFix = [
    $basePath . '/storage',
    $basePath . '/storage/logs',
    $basePath . '/storage/framework',
    $basePath . '/storage/framework/views',
    $basePath . '/bootstrap/cache',
];

foreach ($pathsToFix as $path) {
    if (is_dir($path)) {
        if (chmod($path, 0775)) {
            echo "<p style='color:green'>Fixed permissions for: $path (0775)</p>";
        } else {
            echo "<p style='color:orange'>Failed to set 0775 for: $path. Trying 0755...</p>";
            chmod($path, 0755);
        }
    }
}

// 4. Check .env
echo "<h2>4. Environment Check</h2>";
if (file_exists($basePath . '/.env')) {
    echo "<p style='color:green'>.env file found.</p>";
} else {
    echo "<p style='color:red'>FAILED: .env file NOT found. Copy .env.example to .env</p>";
}

// 5. Try Bootstrapping Laravel (to see hidden errors)
echo "<h2>5. Testing Laravel Bootstrap</h2>";
try {
    require $basePath . '/vendor/autoload.php';
    $app = require_once $basePath . '/bootstrap/app.php';
    echo "<p style='color:green'>Laravel successfully bootstrapped!</p>";
} catch (\Throwable $e) {
    echo "<p style='color:red'>ERROR during bootstrap: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<h2>Done! Please refresh your website now.</h2>";
?>
